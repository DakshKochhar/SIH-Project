import pytest

from app.services.runoff_service import estimate_runoff, runoff_coefficient


def test_runoff_coefficient_increases_with_imperviousness():
    low = runoff_coefficient(0.1)
    high = runoff_coefficient(0.9)
    assert high > low


def test_runoff_coefficient_respects_configured_bounds():
    from app.core.config import settings

    coeff = runoff_coefficient(1.0)
    assert coeff <= settings.RUNOFF_COEFF_MAX
    coeff_zero = runoff_coefficient(0.0)
    assert coeff_zero >= settings.RUNOFF_COEFF_BASE


def test_zero_rainfall_yields_zero_runoff():
    result = estimate_runoff(rainfall_mm=0.0, impervious_fraction=0.8, catchment_area_sqm=500_000)
    assert result["runoff_volume_m3"] == 0.0


def test_extreme_rainfall_scales_runoff_up():
    low = estimate_runoff(rainfall_mm=5.0, impervious_fraction=0.7, catchment_area_sqm=500_000)
    high = estimate_runoff(rainfall_mm=150.0, impervious_fraction=0.7, catchment_area_sqm=500_000)
    assert high["runoff_volume_m3"] > low["runoff_volume_m3"]


def test_higher_imperviousness_increases_runoff_for_same_rainfall():
    pervious = estimate_runoff(rainfall_mm=40.0, impervious_fraction=0.1, catchment_area_sqm=500_000)
    impervious = estimate_runoff(rainfall_mm=40.0, impervious_fraction=0.95, catchment_area_sqm=500_000)
    assert impervious["runoff_volume_m3"] > pervious["runoff_volume_m3"]


def test_negative_rainfall_is_clamped_to_zero():
    result = estimate_runoff(rainfall_mm=-10.0, impervious_fraction=0.5, catchment_area_sqm=100_000)
    assert result["runoff_volume_m3"] == 0.0
