def test_health(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"


def test_current_rainfall_requires_auth(client):
    resp = client.get("/api/v1/rainfall/current")
    assert resp.status_code == 401


def test_current_rainfall(client, auth_headers):
    resp = client.get("/api/v1/rainfall/current", headers=auth_headers)
    assert resp.status_code == 200
    assert "observations" in resp.json()


def test_rainfall_forecast(client, auth_headers):
    resp = client.get("/api/v1/rainfall/forecast", headers=auth_headers)
    assert resp.status_code == 200
    assert "forecast" in resp.json()


def test_flood_predict_missing_coordinates(client, auth_headers):
    resp = client.get("/api/v1/flood/predict", headers=auth_headers)
    assert resp.status_code == 422  # latitude/longitude required


def test_flood_predict(client, auth_headers):
    resp = client.get(
        "/api/v1/flood/predict",
        params={"latitude": 12.9172, "longitude": 77.6228, "horizon": 180},
        headers=auth_headers,
    )
    assert resp.status_code == 200
    body = resp.json()
    assert "flood_probability" in body
    assert body["is_estimated"] is True


def test_flood_predict_invalid_latitude_rejected(client, auth_headers):
    resp = client.get(
        "/api/v1/flood/predict",
        params={"latitude": 999, "longitude": 77.6228},
        headers=auth_headers,
    )
    assert resp.status_code == 422


def test_flood_map_geojson(client, auth_headers):
    resp = client.get("/api/v1/flood/map", headers=auth_headers)
    assert resp.status_code == 200
    body = resp.json()
    assert body["type"] == "FeatureCollection"
    if body["features"]:
        assert body["features"][0]["geometry"]["type"] == "Point"


def test_flood_hotspots(client, auth_headers):
    resp = client.get("/api/v1/flood/hotspots", headers=auth_headers)
    assert resp.status_code == 200
    assert "hotspots" in resp.json()


def test_flood_prediction_detail_not_found(client, auth_headers, operator_token):
    resp = client.get(
        "/api/v1/flood/does-not-exist", headers={"Authorization": f"Bearer {operator_token}"}
    )
    assert resp.status_code == 404


def test_drainage_bottlenecks(client, auth_headers):
    resp = client.get("/api/v1/drainage/bottlenecks", headers=auth_headers)
    assert resp.status_code == 200
    assert "bottlenecks" in resp.json()


def test_road_risk(client, auth_headers):
    resp = client.get("/api/v1/roads/risk", headers=auth_headers)
    assert resp.status_code == 200
    assert "roads" in resp.json()


def test_safe_route(client, auth_headers):
    resp = client.get(
        "/api/v1/routes/safe",
        params={
            "source_lat": 12.9172,
            "source_lng": 77.6228,
            "destination_lat": 13.0358,
            "destination_lng": 77.5970,
        },
        headers=auth_headers,
    )
    assert resp.status_code == 200
    assert "recommended_route" in resp.json()


def test_safe_route_no_route_possible_between_identical_far_points(client, auth_headers):
    # Same source and destination should short-circuit rather than error.
    resp = client.get(
        "/api/v1/routes/safe",
        params={
            "source_lat": 12.9172,
            "source_lng": 77.6228,
            "destination_lat": 12.9172,
            "destination_lng": 77.6228,
        },
        headers=auth_headers,
    )
    assert resp.status_code == 200
    assert resp.json()["avoided_flooded_segments"] == 0


def test_dashboard_summary(client, auth_headers):
    resp = client.get("/api/v1/dashboard/summary", headers=auth_headers)
    assert resp.status_code == 200
    body = resp.json()
    for key in [
        "current_avg_rainfall_mm",
        "highest_risk_areas",
        "critical_road_count",
        "overloaded_drain_count",
        "max_predicted_depth_cm",
        "earliest_predicted_flood_min",
    ]:
        assert key in body


def test_active_alerts(client, auth_headers):
    resp = client.get("/api/v1/alerts/active", headers=auth_headers)
    assert resp.status_code == 200
    assert "alerts" in resp.json()


def test_openapi_docs_available(client):
    resp = client.get("/docs")
    assert resp.status_code == 200
    resp_json = client.get("/openapi.json")
    assert resp_json.status_code == 200
