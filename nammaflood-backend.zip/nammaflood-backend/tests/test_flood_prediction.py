from app.services.flood_prediction_service import _risk_level, _ttf_band, predict_point


def test_predict_point_returns_full_contract():
    result = predict_point(12.9172, 77.6228, horizon_min=180)  # Silk Board Junction
    required = [
        "prediction_id",
        "flood_probability",
        "risk_level",
        "depth_cm",
        "time_to_flood_min",
        "confidence",
        "data_quality",
        "main_drivers",
        "explanation",
        "engine",
    ]
    for key in required:
        assert key in result


def test_flood_probability_is_bounded():
    result = predict_point(12.9257, 77.6774, horizon_min=180)
    assert 0.0 <= result["flood_probability"] <= 1.0
    assert 0.0 <= result["confidence"] <= 1.0


def test_risk_level_bands():
    assert _risk_level(0.1) == "LOW"
    assert _risk_level(0.3) == "MODERATE"
    assert _risk_level(0.6) == "HIGH"
    assert _risk_level(0.9) == "CRITICAL"


def test_ttf_band_classification():
    assert _ttf_band(10) == "CRITICAL"
    assert _ttf_band(25) == "VERY HIGH"
    assert _ttf_band(45) == "HIGH"
    assert _ttf_band(100) == "MODERATE"
    assert _ttf_band(None) == "LOW"


def test_explanation_contributions_are_present_and_bounded():
    result = predict_point(12.9172, 77.6228, horizon_min=180)
    explanation = result["explanation"]
    for key in [
        "rainfall_contribution",
        "terrain_contribution",
        "imperviousness_contribution",
        "drainage_loading_contribution",
    ]:
        assert key in explanation
        assert explanation[key] >= 0


def test_engine_is_honestly_reported_as_rules_when_no_model_trained():
    result = predict_point(12.9172, 77.6228, horizon_min=180)
    # No retrain has been triggered in this test session -> must not claim ML.
    assert result["engine"] == "hybrid_rules"


def test_invalid_coordinates_do_not_crash():
    # Out-of-range-but-numeric coordinates should degrade gracefully rather
    # than raising, since callers may pass bad GPS fixes.
    result = predict_point(999.0, 999.0, horizon_min=60)
    assert 0.0 <= result["flood_probability"] <= 1.0
