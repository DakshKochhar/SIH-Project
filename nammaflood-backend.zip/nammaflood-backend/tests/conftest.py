import os

# Must run before any `app.*` import triggers `app.core.config.get_settings()`
# (which is lru_cache'd on first call), so tests never touch a real Postgres.
os.environ["DATABASE_URL"] = "sqlite:///./test_nammaflood.db"
os.environ["DEMO_MODE"] = "true"
os.environ["SECRET_KEY"] = "test-secret-key"

import pytest
from fastapi.testclient import TestClient

from app.main import app


@pytest.fixture(scope="session")
def client():
    with TestClient(app) as c:
        yield c


@pytest.fixture(scope="session")
def admin_token(client):
    resp = client.post(
        "/api/v1/auth/login",
        json={"email": "admin@nammaflood.demo", "password": "ChangeMe123!"},
    )
    assert resp.status_code == 200, resp.text
    return resp.json()["access_token"]


@pytest.fixture(scope="session")
def operator_token(client):
    resp = client.post(
        "/api/v1/auth/login",
        json={"email": "operator@nammaflood.demo", "password": "ChangeMe123!"},
    )
    assert resp.status_code == 200, resp.text
    return resp.json()["access_token"]


@pytest.fixture(scope="session")
def citizen_token(client):
    resp = client.post(
        "/api/v1/auth/login",
        json={"email": "citizen@nammaflood.demo", "password": "ChangeMe123!"},
    )
    assert resp.status_code == 200, resp.text
    return resp.json()["access_token"]


@pytest.fixture
def auth_headers(citizen_token):
    return {"Authorization": f"Bearer {citizen_token}"}
