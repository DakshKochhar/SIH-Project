from app.services.road_risk_service import classify_road_risk, get_all_road_risks
from app.services.routing_service import get_safe_route


def test_road_risk_classification_bands():
    assert classify_road_risk(10) == "SAFE"
    assert classify_road_risk(40) == "LOW"
    assert classify_road_risk(60) == "HIGH"
    assert classify_road_risk(90) == "CRITICAL"


def test_all_road_risks_have_valid_scores():
    risks = get_all_road_risks(horizon_min=180)
    assert len(risks) > 0
    for r in risks:
        assert 0 <= r["risk_score"] <= 100
        assert r["risk_level"] in ("SAFE", "LOW", "HIGH", "CRITICAL")


def test_safe_route_between_two_known_points():
    # Silk Board Junction -> Hebbal
    result = get_safe_route(12.9172, 77.6228, 13.0358, 77.5970)
    assert len(result["recommended_route"]) >= 1
    assert result["estimated_time_min"] >= 0
    assert result["avoided_flooded_segments"] >= 0


def test_safe_route_same_source_and_destination():
    result = get_safe_route(12.9172, 77.6228, 12.9172, 77.6228)
    assert result["estimated_time_min"] == 0.0
    assert result["risk_score"] == 0.0


def test_safe_route_is_marked_simulated():
    result = get_safe_route(12.9172, 77.6228, 13.0358, 77.5970)
    assert result["is_simulated"] is True
