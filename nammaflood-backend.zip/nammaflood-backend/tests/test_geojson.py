from app.geospatial.geojson import feature_collection, in_bbox, linestring_feature, point_feature


def test_point_feature_uses_lng_lat_order():
    feature = point_feature(lat=12.97, lng=77.59, properties={"risk_level": "HIGH"})
    assert feature.geometry.type == "Point"
    assert feature.geometry.coordinates == [77.59, 12.97]
    assert feature.properties["risk_level"] == "HIGH"


def test_linestring_feature_coordinate_order():
    points = [{"latitude": 12.9, "longitude": 77.6}, {"latitude": 12.95, "longitude": 77.65}]
    feature = linestring_feature(points, properties={"road_id": "ROAD-001"})
    assert feature.geometry.coordinates == [[77.6, 12.9], [77.65, 12.95]]


def test_feature_collection_wraps_features():
    f1 = point_feature(12.9, 77.6, {})
    f2 = point_feature(12.95, 77.65, {})
    fc = feature_collection([f1, f2])
    assert fc.type == "FeatureCollection"
    assert len(fc.features) == 2


def test_in_bbox():
    assert in_bbox(12.95, 77.6, 12.8, 77.4, 13.0, 77.8) is True
    assert in_bbox(0.0, 0.0, 12.8, 77.4, 13.0, 77.8) is False
