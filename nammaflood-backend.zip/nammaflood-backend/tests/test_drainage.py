from app.services.drainage_service import (
    classify_loading,
    estimate_point_loading,
    get_all_segment_statuses,
    get_bottlenecks,
)


def test_classify_loading_bands():
    assert classify_loading(0.2) == "LOW"
    assert classify_loading(0.6) == "MODERATE"
    assert classify_loading(0.9) == "HIGH"
    assert classify_loading(1.2) == "OVERLOADED"


def test_all_segment_statuses_have_required_fields():
    statuses = get_all_segment_statuses()
    assert len(statuses) > 0
    for s in statuses:
        assert s["loading_ratio"] >= 0
        assert s["load_level"] in ("LOW", "MODERATE", "HIGH", "OVERLOADED")


def test_bottlenecks_are_above_threshold():
    from app.core.config import settings

    bottlenecks = get_bottlenecks()
    for b in bottlenecks:
        assert b["loading_ratio"] > settings.DRAIN_BOTTLENECK_THRESHOLD
        assert b["estimated_excess_flow_cms"] >= 0


def test_zero_runoff_gives_background_load_only():
    result = estimate_point_loading(12.9172, 77.6228, runoff_volume_m3=0.0)
    assert result["point_inflow_cms"] == 0.0
    assert result["loading_ratio"] >= 0


def test_large_runoff_increases_loading_ratio():
    small = estimate_point_loading(12.9172, 77.6228, runoff_volume_m3=10.0)
    large = estimate_point_loading(12.9172, 77.6228, runoff_volume_m3=100_000.0)
    assert large["loading_ratio"] > small["loading_ratio"]


def test_zero_capacity_segment_does_not_crash():
    # estimate_point_loading guards capacity==0 with a small epsilon fallback
    result = estimate_point_loading(12.9172, 77.6228, runoff_volume_m3=500.0, window_seconds=60)
    assert result["capacity_cms"] > 0
