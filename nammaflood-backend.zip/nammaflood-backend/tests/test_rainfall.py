from app.services.rainfall_service import get_rainfall_fusion


def test_rainfall_fusion_returns_all_windows():
    result = get_rainfall_fusion(12.9172, 77.6228)  # Silk Board Junction
    for key in [
        "rainfall_15min_mm",
        "rainfall_30min_mm",
        "rainfall_60min_mm",
        "rainfall_3hr_mm",
        "peak_intensity_mm_hr",
        "forecast_accumulation_mm",
    ]:
        assert key in result
        assert result[key] >= 0


def test_rainfall_fusion_is_marked_simulated_in_demo_mode():
    result = get_rainfall_fusion(12.9172, 77.6228)
    assert result["is_simulated"] is True
    assert result["data_quality"] in ("FULL", "PARTIAL", "DEMO")


def test_rainfall_fusion_far_from_any_station_reports_partial_quality():
    # A point far outside the pilot bounding box / station spread.
    result = get_rainfall_fusion(0.0, 0.0)
    assert result["rainfall_60min_mm"] == 0.0
    assert result["data_quality"] == "PARTIAL"


def test_rainfall_windows_are_monotonic_non_decreasing():
    result = get_rainfall_fusion(12.9257, 77.6774)  # Bellandur
    assert result["rainfall_15min_mm"] <= result["rainfall_30min_mm"] <= result["rainfall_60min_mm"]
