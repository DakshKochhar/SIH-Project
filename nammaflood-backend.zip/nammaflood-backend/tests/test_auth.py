def test_login_with_seeded_admin(client):
    resp = client.post(
        "/api/v1/auth/login",
        json={"email": "admin@nammaflood.demo", "password": "ChangeMe123!"},
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["role"] == "ADMIN"
    assert body["access_token"]


def test_login_wrong_password(client):
    resp = client.post(
        "/api/v1/auth/login",
        json={"email": "admin@nammaflood.demo", "password": "wrong"},
    )
    assert resp.status_code == 401


def test_register_new_citizen(client):
    resp = client.post(
        "/api/v1/auth/register",
        json={"email": "new_citizen@example.com", "password": "Passw0rd!", "full_name": "New Citizen"},
    )
    assert resp.status_code == 201
    assert resp.json()["role"] == "CITIZEN"


def test_cannot_self_register_as_admin(client):
    resp = client.post(
        "/api/v1/auth/register",
        json={"email": "wannabe_admin@example.com", "password": "Passw0rd!", "role": "ADMIN"},
    )
    assert resp.status_code == 403


def test_me_requires_auth(client):
    resp = client.get("/api/v1/auth/me")
    assert resp.status_code == 401


def test_me_with_valid_token(client, citizen_token):
    resp = client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {citizen_token}"})
    assert resp.status_code == 200
    assert resp.json()["role"] == "CITIZEN"


def test_citizen_cannot_view_drainage_status(client, citizen_token):
    # /drainage/status is MUNICIPAL_OPERATOR+ only
    resp = client.get("/api/v1/drainage/status", headers={"Authorization": f"Bearer {citizen_token}"})
    assert resp.status_code == 403


def test_operator_can_view_drainage_status(client, operator_token):
    resp = client.get("/api/v1/drainage/status", headers={"Authorization": f"Bearer {operator_token}"})
    assert resp.status_code == 200


def test_citizen_cannot_retrain_model(client, citizen_token):
    resp = client.post("/api/v1/model/retrain", headers={"Authorization": f"Bearer {citizen_token}"})
    assert resp.status_code == 403


def test_admin_retrain_reports_insufficient_data(client, admin_token):
    # The demo historical dataset is intentionally smaller than
    # MODEL_MIN_TRAINING_ROWS, so this should be a 422, not a fabricated success.
    resp = client.post("/api/v1/model/retrain", headers={"Authorization": f"Bearer {admin_token}"})
    assert resp.status_code == 422
