"""
Creates tables (if not present) and seeds the three demo accounts.
The FastAPI app also does this automatically on startup — this script is
for seeding a database without running the API (e.g. CI, or Alembic-managed
environments where you've disabled the app's own create_all).

Usage:
    python scripts/seed_db.py
"""
import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.core.security import hash_password
from app.db.base import Base
from app.db.session import SessionLocal, engine
from app.models.user import User, UserRole


def main() -> None:
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        seed_users = [
            ("admin@nammaflood.demo", "ChangeMe123!", "Demo Admin", UserRole.ADMIN),
            ("operator@nammaflood.demo", "ChangeMe123!", "Demo Municipal Operator", UserRole.MUNICIPAL_OPERATOR),
            ("citizen@nammaflood.demo", "ChangeMe123!", "Demo Citizen", UserRole.CITIZEN),
        ]
        for email, password, name, role in seed_users:
            if db.query(User).filter(User.email == email).first():
                print(f"skip (exists): {email}")
                continue
            db.add(User(email=email, hashed_password=hash_password(password), full_name=name, role=role))
            print(f"created: {email} ({role.value})")
        db.commit()
    finally:
        db.close()


if __name__ == "__main__":
    main()
