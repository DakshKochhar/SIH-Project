"""
Road risk engine.

    road_risk = flood_probability + predicted_depth + drainage_bottleneck_proximity + terrain_risk

normalised to 0-100 and classified into SAFE / LOW / HIGH / CRITICAL using
configurable band edges. Used directly by the safe-routing service to
penalise risky edges.
"""
from datetime import datetime, timezone
from typing import Dict, List

from app.core.config import settings
from app.demo.seed_data import generate_road_network
from app.geospatial.terrain import haversine_km
from app.services.drainage_service import get_bottlenecks
from app.services.flood_prediction_service import predict_point


def classify_road_risk(score: float) -> str:
    if score <= settings.ROAD_RISK_SAFE_MAX:
        return "SAFE"
    if score <= settings.ROAD_RISK_LOW_MAX:
        return "LOW"
    if score <= settings.ROAD_RISK_HIGH_MAX:
        return "HIGH"
    return "CRITICAL"


def _bottleneck_proximity_score(mid_lat: float, mid_lng: float, bottlenecks: List[Dict]) -> float:
    """0-1 score: how close (and how overloaded) the nearest bottleneck is."""
    if not bottlenecks:
        return 0.0
    best = 0.0
    for b in bottlenecks:
        dist_km = haversine_km(mid_lat, mid_lng, b["latitude"], b["longitude"])
        proximity = max(0.0, 1.0 - dist_km / 1.5)  # decays to 0 by 1.5km away
        severity = min(1.0, b["loading_ratio"] / 1.5)
        best = max(best, proximity * severity)
    return round(best, 3)


def get_all_road_risks(horizon_min: int = 180) -> List[Dict]:
    network = generate_road_network()
    bottlenecks = get_bottlenecks()
    now = datetime.now(timezone.utc)

    results = []
    for road in network["roads"]:
        mid_lat = (road["from_lat"] + road["to_lat"]) / 2
        mid_lng = (road["from_lng"] + road["to_lng"]) / 2

        prediction = predict_point(mid_lat, mid_lng, horizon_min)
        bottleneck_score = _bottleneck_proximity_score(mid_lat, mid_lng, bottlenecks)
        terrain_component = prediction["_debug_features"]["terrain_risk"]

        # Each component contributes up to 25 points -> 0-100 scale.
        score = (
            prediction["flood_probability"] * 25
            + min(1.0, prediction["depth_cm"] / 40.0) * 25
            + bottleneck_score * 25
            + terrain_component * 25
        )
        score = round(min(100.0, max(0.0, score)), 1)
        risk_level = classify_road_risk(score)

        travel_penalty = round((score / 100.0) * road["base_travel_time_min"] * 1.5, 1)

        results.append(
            {
                "road_id": road["road_id"],
                "road_name": road["road_name"],
                "risk_score": score,
                "risk_level": risk_level,
                "predicted_depth_cm": prediction["depth_cm"],
                "flood_probability": prediction["flood_probability"],
                "travel_penalty_min": travel_penalty,
                "recommended": risk_level in ("SAFE", "LOW"),
                "from_lat": road["from_lat"],
                "from_lng": road["from_lng"],
                "to_lat": road["to_lat"],
                "to_lng": road["to_lng"],
                "base_travel_time_min": road["base_travel_time_min"],
                "timestamp": now,
            }
        )
    return results
