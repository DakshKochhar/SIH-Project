"""
Alert engine.

Triggers when, for a given prediction:
    flood_probability >= ALERT_PROBABILITY_THRESHOLD
    OR depth_cm         >= ALERT_DEPTH_CM_THRESHOLD
    OR time_to_flood    <= ALERT_TTF_MIN_THRESHOLD
    OR drain_loading    >  ALERT_DRAIN_LOAD_THRESHOLD

Notification channels (SMS/email/push/WhatsApp) are NOT implemented in this
prototype — `NotificationChannel` is an interface so a real integration can
be dropped in later without touching alert-generation logic.
"""
from abc import ABC, abstractmethod
from typing import Dict, List, Optional

from app.core.config import settings
from app.services.flood_prediction_service import predict_area
from app.demo.seed_data import BENGALURU_LOCATIONS


class NotificationChannel(ABC):
    @abstractmethod
    def send(self, alert: Dict) -> None:
        ...


class LogOnlyNotificationChannel(NotificationChannel):
    """Default channel for the prototype: just returns/logs the alert.

    Swap in SMSNotificationChannel / EmailNotificationChannel /
    PushNotificationChannel / WhatsAppNotificationChannel implementations
    of the same interface for production.
    """

    def send(self, alert: Dict) -> None:
        return None


def _severity(risk_level: str) -> str:
    return {"CRITICAL": "CRITICAL", "HIGH": "HIGH", "MODERATE": "MODERATE", "LOW": "LOW"}[risk_level]


def evaluate_prediction_for_alert(prediction: Dict) -> Optional[Dict]:
    probability = prediction["flood_probability"]
    depth = prediction["depth_cm"]
    ttf = prediction["time_to_flood_min"]
    loading_ratio = prediction["_debug_features"]["drain_loading_ratio"]

    triggered = (
        probability >= settings.ALERT_PROBABILITY_THRESHOLD
        or depth >= settings.ALERT_DEPTH_CM_THRESHOLD
        or (ttf is not None and ttf <= settings.ALERT_TTF_MIN_THRESHOLD)
        or loading_ratio > settings.ALERT_DRAIN_LOAD_THRESHOLD
    )
    if not triggered:
        return None

    if ttf is not None:
        message = f"Flooding may occur within {ttf} minutes at this location."
    else:
        message = "Elevated flood risk detected for this location in the next forecast window."

    return {
        "severity": _severity(prediction["risk_level"]),
        "location": {"latitude": prediction["latitude"], "longitude": prediction["longitude"]},
        "message": message,
        "depth_cm": depth,
        "time_to_flood_min": ttf,
        "confidence": prediction["confidence"],
        "flood_probability": probability,
    }


def get_active_alerts(horizon_min: int = 180, channel: Optional[NotificationChannel] = None) -> List[Dict]:
    channel = channel or LogOnlyNotificationChannel()
    predictions = predict_area(
        [{"lat": loc["lat"], "lng": loc["lng"]} for loc in BENGALURU_LOCATIONS], horizon_min
    )
    alerts = []
    for p in predictions:
        alert = evaluate_prediction_for_alert(p)
        if alert:
            channel.send(alert)
            alerts.append(alert)
    return sorted(alerts, key=lambda a: a["flood_probability"], reverse=True)
