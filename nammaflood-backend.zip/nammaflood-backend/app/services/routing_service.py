"""
Safe-route service.

Builds a road graph (NetworkX) with dynamic edge weights:

    weight = base_travel_time + flood_risk_penalty + predicted_depth_penalty

and compares the flood-aware shortest path against the plain shortest-time
path to report how many at-risk segments were avoided.

The demo road graph (app/demo/seed_data.generate_road_network) stands in
for a real OpenStreetMap road extract — see module docstring there. Swapping
in real OSM data means replacing `_build_graph`'s node/edge source; the
weighting and pathfinding logic is unchanged.
"""
from typing import Dict, List

import networkx as nx

from app.demo.seed_data import BENGALURU_LOCATIONS
from app.geospatial.terrain import haversine_km
from app.services.road_risk_service import get_all_road_risks


def _nearest_location_index(lat: float, lng: float) -> int:
    return min(
        range(len(BENGALURU_LOCATIONS)),
        key=lambda i: haversine_km(lat, lng, BENGALURU_LOCATIONS[i]["lat"], BENGALURU_LOCATIONS[i]["lng"]),
    )


def _build_graphs(horizon_min: int = 180):
    risks = get_all_road_risks(horizon_min)
    name_to_index = {loc["name"]: i for i, loc in enumerate(BENGALURU_LOCATIONS)}

    plain = nx.Graph()
    flood_aware = nx.Graph()
    for i in range(len(BENGALURU_LOCATIONS)):
        plain.add_node(i)
        flood_aware.add_node(i)

    risk_by_road = {}
    for r in risks:
        # road_name is "<From> - <To> Rd" per seed_data.generate_road_network
        from_name, rest = r["road_name"].split(" - ")
        to_name = rest.replace(" Rd", "")
        i, j = name_to_index.get(from_name), name_to_index.get(to_name)
        if i is None or j is None:
            continue
        plain.add_edge(i, j, weight=r["base_travel_time_min"], road_id=r["road_id"], risk_level=r["risk_level"])
        depth_penalty = r["predicted_depth_cm"] * 0.5
        risk_penalty = r["travel_penalty_min"]
        # CRITICAL segments get a large additional penalty so Dijkstra avoids
        # them whenever any alternative path exists.
        critical_penalty = 200 if r["risk_level"] == "CRITICAL" else 0
        weight = r["base_travel_time_min"] + risk_penalty + depth_penalty + critical_penalty
        flood_aware.add_edge(i, j, weight=weight, road_id=r["road_id"], risk_level=r["risk_level"])
        risk_by_road[r["road_id"]] = r

    return plain, flood_aware, risk_by_road


def get_safe_route(source_lat: float, source_lng: float, destination_lat: float, destination_lng: float, horizon_min: int = 180) -> Dict:
    plain, flood_aware, risk_by_road = _build_graphs(horizon_min)

    src = _nearest_location_index(source_lat, source_lng)
    dst = _nearest_location_index(destination_lat, destination_lng)

    if src == dst:
        return {
            "recommended_route": [{"latitude": source_lat, "longitude": source_lng}],
            "risk_score": 0.0,
            "estimated_time_min": 0.0,
            "avoided_flooded_segments": 0,
            "is_simulated": True,
        }

    try:
        plain_path = nx.dijkstra_path(plain, src, dst, weight="weight")
    except nx.NetworkXNoPath:
        plain_path = []

    try:
        safe_path = nx.dijkstra_path(flood_aware, src, dst, weight="weight")
    except nx.NetworkXNoPath:
        return {
            "recommended_route": [],
            "risk_score": 100.0,
            "estimated_time_min": 0.0,
            "avoided_flooded_segments": 0,
            "is_simulated": True,
        }

    def path_risky_edges(path, graph):
        risky = set()
        for a, b in zip(path[:-1], path[1:]):
            edge = graph.get_edge_data(a, b)
            if edge and edge.get("risk_level") in ("HIGH", "CRITICAL"):
                risky.add(edge["road_id"])
        return risky

    plain_risky = path_risky_edges(plain_path, plain)
    safe_risky = path_risky_edges(safe_path, flood_aware)
    avoided = len(plain_risky - safe_risky)

    total_time = 0.0
    total_risk = 0.0
    edge_count = 0
    for a, b in zip(safe_path[:-1], safe_path[1:]):
        edge = flood_aware.get_edge_data(a, b)
        road = risk_by_road.get(edge["road_id"])
        if road:
            total_time += road["base_travel_time_min"] + road["travel_penalty_min"]
            total_risk += road["risk_score"]
            edge_count += 1

    avg_risk = round(total_risk / edge_count, 1) if edge_count else 0.0
    route_points = [
        {"latitude": BENGALURU_LOCATIONS[i]["lat"], "longitude": BENGALURU_LOCATIONS[i]["lng"]} for i in safe_path
    ]

    return {
        "recommended_route": route_points,
        "risk_score": avg_risk,
        "estimated_time_min": round(total_time, 1),
        "avoided_flooded_segments": avoided,
        "is_simulated": True,
    }
