"""
Catchment runoff model (rational-method style).

    runoff = rainfall x runoff_coefficient x catchment_area

The runoff coefficient is NOT a single hard-coded constant: it scales
linearly with the local impervious fraction between
`RUNOFF_COEFF_MIN` (fully pervious/green) and `RUNOFF_COEFF_MAX` (fully
impervious/built-up), with a configurable floor `RUNOFF_COEFF_BASE`. This
captures the causal chain from the SIH proposal:

    more impervious surface -> less infiltration -> higher runoff
    -> higher drainage loading -> higher flood risk

All intermediate values are returned (not just the final runoff figure) so
predictions built on top of this stay explainable.
"""
from typing import Dict

from app.core.config import settings


def runoff_coefficient(impervious_fraction: float) -> float:
    impervious_fraction = max(0.0, min(1.0, impervious_fraction))
    span = settings.RUNOFF_COEFF_MAX - settings.RUNOFF_COEFF_MIN
    coeff = settings.RUNOFF_COEFF_MIN + span * impervious_fraction
    return round(max(settings.RUNOFF_COEFF_BASE, min(settings.RUNOFF_COEFF_MAX, coeff)), 3)


def estimate_runoff(rainfall_mm: float, impervious_fraction: float, catchment_area_sqm: float) -> Dict:
    """Returns runoff in cubic metres for the given rainfall depth, plus the
    intermediate coefficient so callers/APIs can show their work.

    rainfall_mm -> metres, x area (sqm) -> m3 of rainfall landing on the
    catchment; x coefficient -> m3 that becomes runoff rather than
    infiltrating.
    """
    coeff = runoff_coefficient(impervious_fraction)
    rainfall_m = max(0.0, rainfall_mm) / 1000.0
    total_rainfall_volume_m3 = rainfall_m * max(0.0, catchment_area_sqm)
    runoff_volume_m3 = round(total_rainfall_volume_m3 * coeff, 2)

    return {
        "runoff_coefficient": coeff,
        "rainfall_mm": rainfall_mm,
        "catchment_area_sqm": catchment_area_sqm,
        "impervious_fraction": round(max(0.0, min(1.0, impervious_fraction)), 3),
        "total_rainfall_volume_m3": round(total_rainfall_volume_m3, 2),
        "runoff_volume_m3": runoff_volume_m3,
    }
