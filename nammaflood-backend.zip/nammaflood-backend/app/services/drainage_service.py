"""
Drainage loading model.

For a segment:
    loading_ratio = estimated_inflow_cms / capacity_cms

Classified using configurable thresholds:
    < DRAIN_LOAD_LOW_MAX            -> LOW
    < DRAIN_LOAD_MODERATE_MAX       -> MODERATE
    < DRAIN_LOAD_HIGH_MAX           -> HIGH
    >= DRAIN_LOAD_HIGH_MAX          -> OVERLOADED

A segment becomes a potential bottleneck when
loading_ratio > DRAIN_BOTTLENECK_THRESHOLD.
"""
import hashlib
import random
from typing import Dict, List, Optional

from app.core.config import settings
from app.geospatial.drainage import nearest_segment
from app.geospatial.terrain import haversine_km
from app.ingestion.drainage import get_drainage_provider
from app.ingestion.rainfall import get_rainfall_provider


def classify_loading(ratio: float) -> str:
    if ratio < settings.DRAIN_LOAD_LOW_MAX:
        return "LOW"
    if ratio < settings.DRAIN_LOAD_MODERATE_MAX:
        return "MODERATE"
    if ratio < settings.DRAIN_LOAD_HIGH_MAX:
        return "HIGH"
    return "OVERLOADED"


def _deterministic_background_fraction(segment_id: str, rainfall_scale: float) -> float:
    """Deterministic pseudo-random baseline load fraction for the demo network.

    Seeded from the segment id (stable across calls) and scaled by the
    current citywide rainfall signal, so heavier rain -> higher background
    loading city-wide, while still being reproducible for a given rainfall
    snapshot (`DEMO_RANDOM_SEED` governs the rainfall snapshot itself).
    """
    seed = int(hashlib.sha256(segment_id.encode()).hexdigest(), 16) % (2**32)
    rng = random.Random(seed)
    base = rng.uniform(0.1, 0.55)
    return min(1.4, base + rainfall_scale)


def _citywide_rainfall_scale() -> float:
    provider = get_rainfall_provider()
    obs = provider.get_current_observations()
    valid = [o["rainfall_mm"] for o in obs if o.get("quality_flag") == "OK"]
    if not valid:
        return 0.0
    avg_mm = sum(valid) / len(valid)
    return min(0.9, avg_mm / 60.0)  # 60mm/hr average => strong extra loading


def get_all_segment_statuses() -> List[Dict]:
    provider = get_drainage_provider()
    segments = provider.get_segments()
    rainfall_scale = _citywide_rainfall_scale()

    statuses = []
    for seg in segments:
        fraction = _deterministic_background_fraction(seg["segment_id"], rainfall_scale)
        current_load_cms = round(seg["capacity_cms"] * fraction, 3)
        ratio = round(current_load_cms / seg["capacity_cms"], 3) if seg["capacity_cms"] > 0 else 0.0
        statuses.append(
            {
                "segment_id": seg["segment_id"],
                "from_node": seg["from_node"],
                "to_node": seg["to_node"],
                "tier": seg["tier"],
                "capacity_cms": seg["capacity_cms"],
                "current_load_cms": current_load_cms,
                "loading_ratio": ratio,
                "load_level": classify_loading(ratio),
                "status": seg["status"],
            }
        )
    return statuses


def get_bottlenecks() -> List[Dict]:
    provider = get_drainage_provider()
    nodes = {n["node_id"]: n for n in provider.get_nodes()}
    statuses = get_all_segment_statuses()

    bottlenecks = []
    for s in statuses:
        if s["loading_ratio"] <= settings.DRAIN_BOTTLENECK_THRESHOLD:
            continue
        from_node = nodes.get(s["from_node"])
        to_node = nodes.get(s["to_node"])
        if not from_node or not to_node:
            continue
        lat = (from_node["latitude"] + to_node["latitude"]) / 2
        lng = (from_node["longitude"] + to_node["longitude"]) / 2
        excess = round(max(0.0, s["current_load_cms"] - s["capacity_cms"]), 3)
        bottlenecks.append(
            {
                "segment_id": s["segment_id"],
                "latitude": round(lat, 5),
                "longitude": round(lng, 5),
                "loading_ratio": s["loading_ratio"],
                "estimated_excess_flow_cms": excess,
                "tier": s["tier"],
            }
        )
    return sorted(bottlenecks, key=lambda b: b["loading_ratio"], reverse=True)


def estimate_point_loading(lat: float, lng: float, runoff_volume_m3: float, window_seconds: int = 1800) -> Dict:
    """Estimate drainage loading for the segment nearest a query point.

    `runoff_volume_m3` (from the runoff service) is converted to a flow
    rate over `window_seconds` (default 30 min) and added on top of the
    segment's simulated background load to get a single point-in-time
    loading ratio for the flood prediction engine.
    """
    provider = get_drainage_provider()
    nodes = provider.get_nodes()
    nodes_by_id = {n["node_id"]: n for n in nodes}
    segments = provider.get_segments()

    segment = nearest_segment(lat, lng, nodes_by_id, segments)
    if segment is None:
        return {
            "segment_id": None,
            "distance_to_drain_km": None,
            "capacity_cms": 0.0,
            "loading_ratio": 0.0,
            "load_level": "LOW",
        }

    statuses = {s["segment_id"]: s for s in get_all_segment_statuses()}
    status = statuses.get(segment["segment_id"])
    background_load = status["current_load_cms"] if status else 0.0

    inflow_cms = runoff_volume_m3 / window_seconds
    total_load = background_load + inflow_cms
    capacity = segment["capacity_cms"] or 0.01
    ratio = round(total_load / capacity, 3)

    from_node = nodes_by_id.get(segment["from_node"])
    dist_km = None
    if from_node:
        dist_km = round(haversine_km(lat, lng, from_node["latitude"], from_node["longitude"]), 3)

    return {
        "segment_id": segment["segment_id"],
        "tier": segment["tier"],
        "distance_to_drain_km": dist_km,
        "capacity_cms": capacity,
        "background_load_cms": round(background_load, 3),
        "point_inflow_cms": round(inflow_cms, 4),
        "loading_ratio": ratio,
        "load_level": classify_loading(ratio),
    }
