"""
Rainfall fusion module.

Combines current station/AWS/ARG observations with the short-range
forecast/nowcast to produce, for any lat/lng, the accumulation windows the
flood engine needs (15/30/60min, 3hr), a peak intensity estimate, and the
forecast accumulation over the requested horizon.

Station -> point interpolation uses IDW (inverse distance weighting) by
default, with "nearest station" as a configurable fallback
(`RAINFALL_INTERPOLATION_METHOD`). Values derived only from a single
snapshot reading (this prototype has no rolling observation history yet)
are clearly proportional estimates, not official sub-hourly IMD figures —
the DEMO/simulation labelling on every input record propagates into
`RainfallFusionOut.is_simulated`.
"""
from typing import Dict, List, Optional

from app.core.config import settings
from app.geospatial.terrain import haversine_km
from app.ingestion.rainfall import get_rainfall_provider


def _idw_interpolate(lat: float, lng: float, observations: List[Dict], value_key: str) -> Optional[Dict]:
    weighted_sum = 0.0
    weight_total = 0.0
    contributing = 0
    for obs in observations:
        if obs.get("quality_flag") in ("MISSING", "OUTLIER"):
            continue
        dist = haversine_km(lat, lng, obs["latitude"], obs["longitude"])
        if dist > settings.RAINFALL_MAX_STATION_DISTANCE_KM:
            continue
        contributing += 1
        if dist < 0.05:
            # Query point essentially at the station -> use it directly.
            return {"value": obs[value_key], "contributing_stations": contributing}
        weight = 1.0 / (dist ** settings.RAINFALL_IDW_POWER)
        weighted_sum += weight * obs[value_key]
        weight_total += weight
    if weight_total == 0.0:
        return None
    return {"value": round(weighted_sum / weight_total, 2), "contributing_stations": contributing}


def _nearest_interpolate(lat: float, lng: float, observations: List[Dict], value_key: str) -> Optional[Dict]:
    valid = [o for o in observations if o.get("quality_flag") not in ("MISSING", "OUTLIER")]
    if not valid:
        return None
    nearest = min(valid, key=lambda o: haversine_km(lat, lng, o["latitude"], o["longitude"]))
    return {"value": nearest[value_key], "contributing_stations": 1}


def _interpolate(lat: float, lng: float, observations: List[Dict], value_key: str) -> Optional[Dict]:
    if settings.RAINFALL_INTERPOLATION_METHOD == "nearest":
        return _nearest_interpolate(lat, lng, observations, value_key)
    return _idw_interpolate(lat, lng, observations, value_key)


def get_rainfall_fusion(lat: float, lng: float, horizon_hours: Optional[int] = None) -> Dict:
    provider = get_rainfall_provider()
    horizon_hours = horizon_hours or settings.RAINFALL_FORECAST_HORIZON_HOURS

    observations = provider.get_current_observations()
    forecast = provider.get_forecast(horizon_hours)

    rainfall_interp = _interpolate(lat, lng, observations, "rainfall_mm")
    intensity_interp = _interpolate(lat, lng, observations, "rainfall_intensity")

    if rainfall_interp is None:
        # No usable station within range -> honestly report zero signal
        # rather than fabricating a plausible-looking number.
        rainfall_60min = 0.0
        peak_intensity = 0.0
        contributing = 0
        data_quality = "PARTIAL"
    else:
        rainfall_60min = rainfall_interp["value"]
        peak_intensity = intensity_interp["value"] if intensity_interp else rainfall_60min * 2
        contributing = rainfall_interp["contributing_stations"]
        data_quality = "DEMO" if settings.DEMO_MODE else ("FULL" if contributing >= 3 else "PARTIAL")

    # Sub-hourly windows are proportional estimates from the single trailing
    # reading available in this prototype (see module docstring).
    rainfall_15min = round(rainfall_60min * 0.28, 2)
    rainfall_30min = round(rainfall_60min * 0.55, 2)

    # Forecast accumulation over the horizon: sum interpolated forecast
    # rainfall at the nearest forecast grid points within the horizon window.
    horizon_minutes = horizon_hours * 60
    relevant_forecast = [f for f in forecast]
    forecast_interp_values = []
    # Interpolate forecast per timestep bucket using nearest forecast grid point
    # (forecast grids are coarser than stations in this prototype).
    if relevant_forecast:
        nearest_grid_id = min(
            relevant_forecast, key=lambda f: haversine_km(lat, lng, f["latitude"], f["longitude"])
        )["grid_id"]
        forecast_interp_values = [f["rainfall_mm"] for f in relevant_forecast if f["grid_id"] == nearest_grid_id]
    forecast_accumulation = round(sum(forecast_interp_values), 2)

    rainfall_3hr = round(rainfall_60min * 2.4 + forecast_accumulation * 0.4, 2)

    return {
        "latitude": lat,
        "longitude": lng,
        "rainfall_15min_mm": rainfall_15min,
        "rainfall_30min_mm": rainfall_30min,
        "rainfall_60min_mm": rainfall_60min,
        "rainfall_3hr_mm": rainfall_3hr,
        "peak_intensity_mm_hr": peak_intensity,
        "forecast_accumulation_mm": forecast_accumulation,
        "interpolation_method": settings.RAINFALL_INTERPOLATION_METHOD,
        "contributing_stations": contributing,
        "data_quality": data_quality,
        "is_simulated": True,
    }
