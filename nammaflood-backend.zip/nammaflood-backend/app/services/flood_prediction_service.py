"""
Flood prediction engine — orchestrates the full pipeline for one point:

    rainfall fusion -> catchment runoff -> drainage loading -> terrain risk
    -> hybrid physics+ML ensemble -> depth / time-to-flood / explanation

This is the module that answers `GET /api/v1/flood/predict`.
"""
import uuid
from datetime import datetime, timezone
from typing import Dict, List, Optional

from app.core.config import settings
from app.demo import seed_data
from app.geospatial.catchment import nearest_catchment, local_impervious_fraction
from app.geospatial.terrain import nearest_terrain_cell, terrain_risk_score
from app.ingestion.drainage import get_drainage_provider
from app.ingestion.landcover import get_landcover_provider
from app.ingestion.terrain import get_terrain_provider
from app.ml.predict import predict_flood
from app.services.drainage_service import estimate_point_loading
from app.services.rainfall_service import get_rainfall_fusion
from app.services.runoff_service import estimate_runoff


def _ttf_band(minutes: Optional[int]) -> str:
    if minutes is None:
        return "LOW"
    if minutes <= settings.TTF_CRITICAL_MAX_MIN:
        return "CRITICAL"
    if minutes <= settings.TTF_VERY_HIGH_MAX_MIN:
        return "VERY HIGH"
    if minutes <= settings.TTF_HIGH_MAX_MIN:
        return "HIGH"
    if minutes <= settings.TTF_MODERATE_MAX_MIN:
        return "MODERATE"
    return "LOW"


def _risk_level(probability: float) -> str:
    if probability >= 0.75:
        return "CRITICAL"
    if probability >= 0.5:
        return "HIGH"
    if probability >= 0.25:
        return "MODERATE"
    return "LOW"


def _main_drivers(explanation: Dict[str, float], features: Dict[str, float]) -> List[str]:
    drivers = []
    ranked = sorted(explanation.items(), key=lambda kv: kv[1], reverse=True)
    labels = {
        "rainfall_contribution": "High rainfall intensity",
        "terrain_contribution": "Low terrain elevation / local low point",
        "imperviousness_contribution": "High impervious surface",
        "drainage_loading_contribution": "Drainage segment approaching or over capacity",
    }
    for key, value in ranked:
        if key in labels and value > 0.03:
            drivers.append(labels[key])
    if not drivers:
        drivers.append("No single dominant driver — overall low risk")
    return drivers[:4]


def _confidence(data_quality: str, contributing_stations: int, ml_bonus: float) -> float:
    base = {"FULL": 0.8, "PARTIAL": 0.6, "DEMO": 0.55}.get(data_quality, 0.5)
    station_bonus = min(0.1, contributing_stations * 0.02)
    confidence = min(0.97, base + station_bonus + ml_bonus)
    return round(confidence, 2)


def predict_point(lat: float, lng: float, horizon_min: int = 180) -> Dict:
    horizon_hours = max(1, round(horizon_min / 60))

    # 1. Rainfall fusion
    rainfall = get_rainfall_fusion(lat, lng, horizon_hours=horizon_hours)

    # 2. Terrain risk
    terrain_provider = get_terrain_provider()
    terrain_cells = terrain_provider.get_terrain_cells()
    terrain_cell = nearest_terrain_cell(lat, lng, terrain_cells)
    terrain_score = terrain_risk_score(terrain_cell) if terrain_cell else 0.3

    # 3. Imperviousness (from land cover)
    landcover_provider = get_landcover_provider()
    landcover_cells = landcover_provider.get_landcover_cells()
    impervious_fraction = local_impervious_fraction(lat, lng, landcover_cells)

    # 4. Catchment + runoff
    drainage_provider = get_drainage_provider()
    nodes = drainage_provider.get_nodes()
    catchments = seed_data.generate_catchments(nodes)
    catchment = nearest_catchment(lat, lng, catchments)
    catchment_area = catchment["area_sqm"] if catchment else 400_000.0

    runoff = estimate_runoff(
        rainfall_mm=rainfall["rainfall_3hr_mm"],
        impervious_fraction=impervious_fraction,
        catchment_area_sqm=catchment_area,
    )

    # 5. Drainage loading at this point
    loading = estimate_point_loading(lat, lng, runoff["runoff_volume_m3"], window_seconds=horizon_min * 60)

    # 6. Assemble feature vector for the hybrid model
    features = {
        "rainfall_15min": rainfall["rainfall_15min_mm"],
        "rainfall_30min": rainfall["rainfall_30min_mm"],
        "rainfall_60min": rainfall["rainfall_60min_mm"],
        "rainfall_3hr": rainfall["rainfall_3hr_mm"],
        "forecast_rainfall": rainfall["forecast_accumulation_mm"],
        "rainfall_intensity": rainfall["peak_intensity_mm_hr"],
        "elevation": terrain_cell["elevation_m"] if terrain_cell else 900.0,
        "slope": terrain_cell["slope_deg"] if terrain_cell else 2.0,
        "impervious_fraction": impervious_fraction,
        "catchment_area": catchment_area,
        "runoff": runoff["runoff_volume_m3"],
        "drain_capacity": loading["capacity_cms"],
        "drain_loading_ratio": loading["loading_ratio"],
        "distance_to_drain_km": loading["distance_to_drain_km"] or 0.5,
        "local_low_point": 1.0 if (terrain_cell and terrain_cell.get("is_local_low_point")) else 0.0,
        "historical_flood_frequency": 0.2 if (terrain_cell and terrain_cell.get("is_local_low_point")) else 0.05,
        "terrain_risk": terrain_score,
    }

    # 7. Hybrid physics+ML prediction
    prediction = predict_flood(features)
    probability = prediction["probability"]
    risk_level = _risk_level(probability)
    ttf_min = prediction["time_to_flood_min"]

    data_quality = rainfall["data_quality"]
    confidence = _confidence(data_quality, rainfall["contributing_stations"], prediction["ml_confidence_bonus"])
    main_drivers = _main_drivers(prediction["explanation"], features)

    return {
        "prediction_id": str(uuid.uuid4()),
        "latitude": lat,
        "longitude": lng,
        "timestamp": datetime.now(timezone.utc),
        "forecast_horizon_min": horizon_min,
        "flood_probability": probability,
        "risk_level": risk_level,
        "depth_cm": prediction["depth_cm"],
        "time_to_flood_min": ttf_min,
        "confidence": confidence,
        "data_quality": data_quality,
        "main_drivers": main_drivers,
        "explanation": prediction["explanation"],
        "engine": prediction["engine"],
        "is_estimated": True,
        "is_simulated": True,
        "_debug_features": features,  # not returned by the API schema, useful for tests/logging
    }


def predict_area(locations: List[Dict[str, float]], horizon_min: int = 180) -> List[Dict]:
    return [predict_point(loc["lat"], loc["lng"], horizon_min) for loc in locations]


def get_hotspots(min_risk: str = "HIGH", horizon_min: int = 180) -> List[Dict]:
    """Predict across the demo location set and return only high-risk points."""
    order = {"LOW": 0, "MODERATE": 1, "HIGH": 2, "CRITICAL": 3}
    threshold = order.get(min_risk, 2)
    predictions = predict_area(
        [{"lat": loc["lat"], "lng": loc["lng"]} for loc in seed_data.BENGALURU_LOCATIONS], horizon_min
    )
    return [p for p in predictions if order.get(p["risk_level"], 0) >= threshold]
