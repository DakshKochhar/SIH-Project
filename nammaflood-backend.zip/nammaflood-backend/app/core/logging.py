"""
Structured logging configuration.

Every ingestion run, prediction, API request and error is logged as a single
JSON line so logs can be shipped to any aggregator (ELK, CloudWatch, etc.)
without a custom parser.
"""
import logging
import sys
import json
from datetime import datetime, timezone
from typing import Any, Dict


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: Dict[str, Any] = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        extra = getattr(record, "extra_fields", None)
        if extra:
            payload.update(extra)
        return json.dumps(payload, default=str)


def configure_logging(level: str = "INFO") -> None:
    root = logging.getLogger()
    root.setLevel(level)
    root.handlers.clear()

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JsonFormatter())
    root.addHandler(handler)


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)


def log_event(logger: logging.Logger, level: str, message: str, **fields: Any) -> None:
    """Convenience helper: log_event(logger, 'info', 'ingestion done', station_count=12)."""
    record_level = getattr(logging, level.upper(), logging.INFO)
    logger.log(record_level, message, extra={"extra_fields": fields})
