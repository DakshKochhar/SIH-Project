"""
Central configuration for NammaFlood backend.

Every threshold called out in the SIH26085 proposal (drain-loading bands,
time-to-flood bands, road-risk bands, alert thresholds, runoff coefficients)
is exposed here as a configurable value instead of being hard-coded inside
business logic. Values are loaded from environment variables / .env so they
can be tuned per-deployment (pilot watershed vs city-wide, etc.) without a
code change.
"""
from functools import lru_cache
from typing import List

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # --- App ---
    APP_NAME: str = "NammaFlood Backend"
    APP_VERSION: str = "0.1.0-prototype"
    ENVIRONMENT: str = "development"
    DEBUG: bool = True
    API_V1_PREFIX: str = "/api/v1"

    # --- Pilot area (Bengaluru) ---
    PILOT_CITY: str = "Bengaluru"
    PILOT_BBOX_MIN_LAT: float = 12.83
    PILOT_BBOX_MIN_LNG: float = 77.45
    PILOT_BBOX_MAX_LAT: float = 13.10
    PILOT_BBOX_MAX_LNG: float = 77.75

    # --- Database ---
    # Postgres/PostGIS is the intended production store. DATABASE_URL can be
    # overridden to sqlite for local dev / CI where PostGIS isn't available;
    # geometry columns then degrade to WKT text (see app/db/base.py).
    DATABASE_URL: str = "postgresql+psycopg2://nammaflood:nammaflood@localhost:5432/nammaflood"
    SQL_ECHO: bool = False

    # --- Redis / background jobs ---
    REDIS_URL: str = "redis://localhost:6379/0"
    USE_CELERY: bool = False  # False => lightweight asyncio scheduler (prototype default)
    UPDATE_INTERVAL_SECONDS: int = 300

    # --- Auth / security ---
    SECRET_KEY: str = "CHANGE_ME_IN_PRODUCTION_this_is_a_demo_key_only"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 120
    CORS_ORIGINS: List[str] = ["*"]

    # --- Rate limiting ---
    RATE_LIMIT_PER_MINUTE: int = 120

    # --- Demo / simulation mode ---
    DEMO_MODE: bool = True
    DEMO_RANDOM_SEED: int = 26085  # deterministic => reproducible demo runs

    # --- Rainfall fusion ---
    RAINFALL_INTERPOLATION_METHOD: str = "idw"  # "idw" | "nearest"
    RAINFALL_IDW_POWER: float = 2.0
    RAINFALL_MAX_STATION_DISTANCE_KM: float = 15.0
    RAINFALL_FORECAST_HORIZON_HOURS: int = 3

    # --- Runoff model (rational-method style, configurable coefficients) ---
    RUNOFF_COEFF_MIN: float = 0.15   # fully pervious / green cover
    RUNOFF_COEFF_MAX: float = 0.95   # fully impervious / built-up
    RUNOFF_COEFF_BASE: float = 0.30  # floor applied even at 0% imperviousness

    # --- Drainage loading classification thresholds ---
    DRAIN_LOAD_LOW_MAX: float = 0.5
    DRAIN_LOAD_MODERATE_MAX: float = 0.8
    DRAIN_LOAD_HIGH_MAX: float = 1.0
    DRAIN_BOTTLENECK_THRESHOLD: float = 0.8  # loading_ratio above which a segment is flagged

    # --- Time-to-flood bands (minutes) ---
    TTF_CRITICAL_MAX_MIN: int = 15
    TTF_VERY_HIGH_MAX_MIN: int = 30
    TTF_HIGH_MAX_MIN: int = 60
    TTF_MODERATE_MAX_MIN: int = 120

    # --- Road risk bands (0-100) ---
    ROAD_RISK_SAFE_MAX: float = 25.0
    ROAD_RISK_LOW_MAX: float = 50.0
    ROAD_RISK_HIGH_MAX: float = 75.0

    # --- Alert thresholds ---
    ALERT_PROBABILITY_THRESHOLD: float = 0.7
    ALERT_DEPTH_CM_THRESHOLD: float = 15.0
    ALERT_TTF_MIN_THRESHOLD: int = 30
    ALERT_DRAIN_LOAD_THRESHOLD: float = 1.0

    # --- Hybrid rule-engine component weights (must sum to ~1.0) ---
    RULE_WEIGHT_RAINFALL: float = 0.35
    RULE_WEIGHT_TERRAIN: float = 0.20
    RULE_WEIGHT_IMPERVIOUS: float = 0.15
    RULE_WEIGHT_DRAINAGE: float = 0.30
    RAINFALL_NORMALISATION_MM: float = 100.0  # 3hr rainfall considered "extreme" at this level

    # --- Model / ML ---
    MODEL_ARTIFACT_DIR: str = "data/models"
    MODEL_MIN_TRAINING_ROWS: int = 200  # below this, hybrid rules-only engine is used

    # --- External provider toggles (all default to DEMO providers) ---
    RAINFALL_PROVIDER: str = "demo"     # "demo" | "imd_ksndmc"
    DRAINAGE_PROVIDER: str = "demo"     # "demo" | "bbmp_ksrsac"
    TERRAIN_PROVIDER: str = "demo"      # "demo" | "bhuvan_cartodem"
    LANDCOVER_PROVIDER: str = "demo"    # "demo" | "esa_worldcover"

    # Real-provider credentials (unused while provider=="demo")
    IMD_API_KEY: str = ""
    KSNDMC_API_KEY: str = ""
    BHUVAN_API_KEY: str = ""


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
