from fastapi import APIRouter, Depends, Query

from app.api.deps import require_citizen_or_above
from app.demo.seed_data import BENGALURU_LOCATIONS
from app.ingestion.rainfall import get_rainfall_provider
from app.services.drainage_service import get_all_segment_statuses
from app.services.flood_prediction_service import predict_area
from app.services.road_risk_service import get_all_road_risks

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


@router.get(
    "/summary",
    summary="System summary for a control-room dashboard",
    description="Aggregate snapshot: current rainfall, highest-risk areas, critical road count, overloaded drain count, max predicted depth, earliest predicted flood.",
)
def dashboard_summary(
    horizon: int = Query(default=180, ge=15, le=180),
    user=Depends(require_citizen_or_above),
):
    rainfall_provider = get_rainfall_provider()
    observations = rainfall_provider.get_current_observations()
    valid_obs = [o["rainfall_mm"] for o in observations if o["quality_flag"] == "OK"]
    avg_rainfall = round(sum(valid_obs) / len(valid_obs), 1) if valid_obs else 0.0

    predictions = predict_area(
        [{"lat": loc["lat"], "lng": loc["lng"]} for loc in BENGALURU_LOCATIONS], horizon
    )
    order = {"LOW": 0, "MODERATE": 1, "HIGH": 2, "CRITICAL": 3}
    highest_risk = sorted(predictions, key=lambda p: order.get(p["risk_level"], 0), reverse=True)[:5]

    segment_statuses = get_all_segment_statuses()
    overloaded_drains = [s for s in segment_statuses if s["load_level"] == "OVERLOADED"]

    road_risks = get_all_road_risks(horizon_min=horizon)
    critical_roads = [r for r in road_risks if r["risk_level"] == "CRITICAL"]

    max_depth = max((p["depth_cm"] for p in predictions), default=0.0)
    ttf_values = [p["time_to_flood_min"] for p in predictions if p["time_to_flood_min"] is not None]
    earliest_flood_min = min(ttf_values) if ttf_values else None

    return {
        "current_avg_rainfall_mm": avg_rainfall,
        "highest_risk_areas": [
            {
                "latitude": p["latitude"],
                "longitude": p["longitude"],
                "risk_level": p["risk_level"],
                "flood_probability": p["flood_probability"],
                "depth_cm": p["depth_cm"],
            }
            for p in highest_risk
        ],
        "critical_road_count": len(critical_roads),
        "overloaded_drain_count": len(overloaded_drains),
        "max_predicted_depth_cm": max_depth,
        "earliest_predicted_flood_min": earliest_flood_min,
        "forecast_horizon_min": horizon,
    }
