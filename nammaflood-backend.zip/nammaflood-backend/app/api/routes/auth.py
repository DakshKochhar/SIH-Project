from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.core.security import create_access_token, hash_password, verify_password
from app.db.session import get_db
from app.models.user import User
from app.schemas.auth import LoginRequest, Token, UserCreate, UserOut

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post(
    "/register",
    response_model=UserOut,
    status_code=status.HTTP_201_CREATED,
    summary="Register a new user",
    description="Creates a user with role CITIZEN by default. Admins can be created via the seed script (see README) — this endpoint does not allow self-registering as ADMIN.",
)
def register(payload: UserCreate, db: Session = Depends(get_db)):
    if payload.role.value == "ADMIN":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Cannot self-register as ADMIN.")
    existing = db.query(User).filter(User.email == payload.email).first()
    if existing:
        raise HTTPException(status.HTTP_409_CONFLICT, "Email already registered.")
    user = User(
        email=payload.email,
        hashed_password=hash_password(payload.password),
        full_name=payload.full_name,
        role=payload.role,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@router.post(
    "/login",
    response_model=Token,
    summary="Login and obtain a JWT",
    description="Exchanges email/password for a bearer token. Use the token in `Authorization: Bearer <token>`.",
)
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == payload.email).first()
    if not user or not verify_password(payload.password, user.hashed_password):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Incorrect email or password.")
    if not user.is_active:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "User is inactive.")
    token = create_access_token(subject=user.email, role=user.role.value)
    return Token(access_token=token, role=user.role)


@router.get(
    "/me",
    response_model=UserOut,
    summary="Current user profile",
)
def me(user: User = Depends(get_current_user)):
    return user
