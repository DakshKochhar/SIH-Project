from fastapi import APIRouter, Depends, Query

from app.api.deps import require_citizen_or_above
from app.core.config import settings
from app.ingestion.rainfall import get_rainfall_provider
from app.schemas.rainfall import RainfallFusionOut
from app.services.rainfall_service import get_rainfall_fusion

router = APIRouter(prefix="/rainfall", tags=["rainfall"])


@router.get(
    "/current",
    summary="Current rainfall observations",
    description=(
        "Returns current station/AWS/ARG rainfall observations across the pilot area. "
        "In DEMO_MODE these are clearly-labelled simulated readings, not live IMD/KSNDMC data."
    ),
    response_description="List of station observations.",
)
def current_rainfall(user=Depends(require_citizen_or_above)):
    provider = get_rainfall_provider()
    return {"count": None, "observations": provider.get_current_observations()}


@router.get(
    "/forecast",
    summary="Short-range rainfall forecast (0-3hr)",
    description="Returns the short-range rainfall forecast/nowcast grid for the pilot area.",
)
def rainfall_forecast(
    horizon_hours: int = Query(default=settings.RAINFALL_FORECAST_HORIZON_HOURS, ge=1, le=3),
    user=Depends(require_citizen_or_above),
):
    provider = get_rainfall_provider()
    return {"horizon_hours": horizon_hours, "forecast": provider.get_forecast(horizon_hours)}


@router.get(
    "/fusion",
    response_model=RainfallFusionOut,
    summary="Fused rainfall estimate at a point",
    description="Runs the rainfall fusion module (IDW/nearest interpolation + multi-window accumulation) for one lat/lng.",
)
def rainfall_fusion(
    latitude: float = Query(...),
    longitude: float = Query(...),
    user=Depends(require_citizen_or_above),
):
    return get_rainfall_fusion(latitude, longitude)
