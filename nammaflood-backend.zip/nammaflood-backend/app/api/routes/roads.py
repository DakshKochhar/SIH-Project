from fastapi import APIRouter, Depends, Query

from app.api.deps import require_citizen_or_above
from app.services.road_risk_service import get_all_road_risks

router = APIRouter(prefix="/roads", tags=["roads"])


@router.get(
    "/risk",
    summary="Road-segment flood risk",
    description="Dynamic 0-100 risk score per road segment, combining flood probability, predicted depth, drainage-bottleneck proximity and terrain risk.",
)
def road_risk(
    horizon: int = Query(default=180, ge=15, le=180),
    user=Depends(require_citizen_or_above),
):
    risks = get_all_road_risks(horizon_min=horizon)
    return {"count": len(risks), "roads": risks}
