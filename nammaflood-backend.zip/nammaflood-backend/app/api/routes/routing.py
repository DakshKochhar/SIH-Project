from fastapi import APIRouter, Depends, Query

from app.api.deps import require_citizen_or_above
from app.schemas.road import SafeRouteResponse
from app.services.routing_service import get_safe_route

router = APIRouter(prefix="/routes", tags=["routes"])


@router.get(
    "/safe",
    response_model=SafeRouteResponse,
    summary="Flood-aware safe route",
    description=(
        "Computes a flood-risk-aware route between two points using dynamic edge weights "
        "(base travel time + flood-risk penalty + predicted-depth penalty) and reports how many "
        "at-risk segments were avoided versus the plain shortest-time route."
    ),
)
def safe_route(
    source_lat: float = Query(...),
    source_lng: float = Query(...),
    destination_lat: float = Query(...),
    destination_lng: float = Query(...),
    horizon: int = Query(default=180, ge=15, le=180),
    user=Depends(require_citizen_or_above),
):
    return get_safe_route(source_lat, source_lng, destination_lat, destination_lng, horizon_min=horizon)
