from fastapi import APIRouter, Depends, HTTPException

from app.api.deps import require_admin
from app.ingestion.historical_flood import get_historical_flood_provider
from app.ml.model import reset_model_cache
from app.ml.train import train_models

router = APIRouter(prefix="/model", tags=["model"])


@router.post(
    "/retrain",
    summary="Retrain the flood ML models (ADMIN only)",
    description=(
        "Trains flood-probability (classification), depth (regression) and time-to-flood (regression) "
        "models from historical flood-event data. Refuses to train (422) if there are fewer than "
        "`MODEL_MIN_TRAINING_ROWS` labelled events — in that case the system continues using the "
        "hybrid rules-only engine rather than training on insufficient data."
    ),
    responses={422: {"description": "Insufficient historical training data."}},
)
def retrain(user=Depends(require_admin)):
    provider = get_historical_flood_provider()
    events = provider.get_events()
    try:
        report = train_models(events)
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from exc
    reset_model_cache()
    return {"status": "trained", "report": report}
