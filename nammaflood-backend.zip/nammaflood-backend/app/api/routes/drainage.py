from fastapi import APIRouter, Depends

from app.api.deps import require_citizen_or_above, require_operator_or_above
from app.services.drainage_service import get_all_segment_statuses, get_bottlenecks

router = APIRouter(prefix="/drainage", tags=["drainage"])


@router.get(
    "/status",
    summary="Drainage network status",
    description="Loading ratio and classification (LOW/MODERATE/HIGH/OVERLOADED) for every drain segment.",
)
def drainage_status(user=Depends(require_operator_or_above)):
    statuses = get_all_segment_statuses()
    return {"count": len(statuses), "segments": statuses}


@router.get(
    "/bottlenecks",
    summary="Drainage bottlenecks",
    description="Segments currently above the configured bottleneck loading-ratio threshold, with estimated excess flow.",
)
def drainage_bottlenecks(user=Depends(require_citizen_or_above)):
    bottlenecks = get_bottlenecks()
    return {"count": len(bottlenecks), "bottlenecks": bottlenecks}
