from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query

from app.api.deps import require_citizen_or_above, require_operator_or_above
from app.geospatial.geojson import feature_collection, point_feature
from app.schemas.flood import FloodPredictionOut
from app.services.flood_prediction_service import get_hotspots, predict_point

router = APIRouter(prefix="/flood", tags=["flood"])

# In-memory store of recent predictions so GET /flood/{prediction_id} works
# without requiring a DB round-trip for the prototype. A production system
# would always read this from the `flood_predictions` table instead.
_recent_predictions: dict = {}


def _store(prediction: dict) -> dict:
    _recent_predictions[prediction["prediction_id"]] = prediction
    if len(_recent_predictions) > 500:
        oldest_key = next(iter(_recent_predictions))
        _recent_predictions.pop(oldest_key, None)
    return prediction


def _public(prediction: dict) -> dict:
    """Strip internal debug fields (raw feature vector) before returning to clients."""
    return {k: v for k, v in prediction.items() if not k.startswith("_")}


@router.get(
    "/predict",
    summary="Predict flood risk at a point",
    description=(
        "Runs the full hybrid pipeline (rainfall fusion, runoff, drainage loading, terrain, "
        "hybrid physics+ML ensemble) for one location and forecast horizon. "
        "All figures are ESTIMATES — see `confidence` and `data_quality`."
    ),
    response_description="Flood prediction with explainability.",
)
def predict_flood_point(
    latitude: float = Query(..., ge=-90, le=90),
    longitude: float = Query(..., ge=-180, le=180),
    horizon: int = Query(default=180, ge=15, le=180, description="Forecast horizon in minutes (max 180 = 3hr)."),
    user=Depends(require_citizen_or_above),
):
    prediction = predict_point(latitude, longitude, horizon)
    _store(prediction)
    return _public(prediction)


@router.get(
    "/map",
    summary="Area flood-risk map (GeoJSON)",
    description="Returns flood predictions across the pilot's known locations as a GeoJSON FeatureCollection, optionally filtered by bounding box.",
)
def flood_map(
    min_lat: Optional[float] = None,
    min_lng: Optional[float] = None,
    max_lat: Optional[float] = None,
    max_lng: Optional[float] = None,
    horizon: int = Query(default=180, ge=15, le=180),
    user=Depends(require_citizen_or_above),
):
    predictions = get_hotspots(min_risk="LOW", horizon_min=horizon)  # LOW threshold => return all
    features = []
    for p in predictions:
        if min_lat is not None and not (min_lat <= p["latitude"] <= max_lat and min_lng <= p["longitude"] <= max_lng):
            continue
        features.append(
            point_feature(
                p["latitude"],
                p["longitude"],
                {
                    "prediction_id": p["prediction_id"],
                    "risk_level": p["risk_level"],
                    "probability": p["flood_probability"],
                    "depth_cm": p["depth_cm"],
                    "time_to_flood_min": p["time_to_flood_min"],
                    "confidence": p["confidence"],
                },
            )
        )
        _store(p)
    return feature_collection(features)


@router.get(
    "/hotspots",
    summary="Flood hotspots",
    description="Returns locations currently at or above a given risk level (default HIGH).",
)
def flood_hotspots(
    min_risk: str = Query(default="HIGH", pattern="^(LOW|MODERATE|HIGH|CRITICAL)$"),
    horizon: int = Query(default=180, ge=15, le=180),
    user=Depends(require_citizen_or_above),
):
    hotspots = get_hotspots(min_risk=min_risk, horizon_min=horizon)
    for p in hotspots:
        _store(p)
    return {"count": len(hotspots), "hotspots": hotspots}


@router.get(
    "/{prediction_id}",
    response_model=FloodPredictionOut,
    summary="Prediction detail",
    description="Returns full detail (including explanation) for a previously generated prediction id.",
    responses={404: {"description": "Prediction id not found (predictions are kept in-memory for this prototype)."}},
)
def get_prediction(prediction_id: str, user=Depends(require_operator_or_above)):
    prediction = _recent_predictions.get(prediction_id)
    if not prediction:
        raise HTTPException(404, "Prediction not found. Predictions are cached in-memory in this prototype.")
    return _public(prediction)
