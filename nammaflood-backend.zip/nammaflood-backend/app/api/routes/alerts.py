from fastapi import APIRouter, Depends, Query

from app.api.deps import require_citizen_or_above
from app.services.alert_service import get_active_alerts

router = APIRouter(prefix="/alerts", tags=["alerts"])


@router.get(
    "/active",
    summary="Active flood alerts",
    description="Alerts currently triggered by probability, depth, time-to-flood or drainage-overload thresholds.",
)
def active_alerts(
    horizon: int = Query(default=180, ge=15, le=180),
    user=Depends(require_citizen_or_above),
):
    alerts = get_active_alerts(horizon_min=horizon)
    return {"count": len(alerts), "alerts": alerts}
