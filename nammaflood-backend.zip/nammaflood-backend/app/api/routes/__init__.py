from fastapi import APIRouter

from app.api.routes import (
    health,
    rainfall,
    flood,
    drainage,
    roads,
    routing,
    dashboard,
    auth,
    model,
    alerts,
)

api_router = APIRouter()
api_router.include_router(health.router)  # /health (no prefix, no v1 -- simple liveness probe)

v1_router = APIRouter()
v1_router.include_router(rainfall.router)
v1_router.include_router(flood.router)
v1_router.include_router(drainage.router)
v1_router.include_router(roads.router)
v1_router.include_router(routing.router)
v1_router.include_router(dashboard.router)
v1_router.include_router(auth.router)
v1_router.include_router(model.router)
v1_router.include_router(alerts.router)
