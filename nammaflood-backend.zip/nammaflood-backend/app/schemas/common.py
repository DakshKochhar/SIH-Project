"""
Shared schema primitives, notably minimal GeoJSON models.

Coordinate order follows the GeoJSON spec: [longitude, latitude].
"""
from enum import Enum
from typing import List, Literal, Optional, Union

from pydantic import BaseModel, Field


class RiskLevel(str, Enum):
    LOW = "LOW"
    MODERATE = "MODERATE"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class DrainLoadLevel(str, Enum):
    LOW = "LOW"
    MODERATE = "MODERATE"
    HIGH = "HIGH"
    OVERLOADED = "OVERLOADED"


class RoadRiskLevel(str, Enum):
    SAFE = "SAFE"
    LOW = "LOW"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class DataQuality(str, Enum):
    FULL = "FULL"
    PARTIAL = "PARTIAL"
    DEMO = "DEMO"


class GeoJSONPointGeometry(BaseModel):
    type: Literal["Point"] = "Point"
    coordinates: List[float] = Field(..., min_length=2, max_length=2, description="[lng, lat]")


class GeoJSONLineStringGeometry(BaseModel):
    type: Literal["LineString"] = "LineString"
    coordinates: List[List[float]]


class GeoJSONFeature(BaseModel):
    type: Literal["Feature"] = "Feature"
    geometry: Union[GeoJSONPointGeometry, GeoJSONLineStringGeometry]
    properties: dict = Field(default_factory=dict)


class GeoJSONFeatureCollection(BaseModel):
    type: Literal["FeatureCollection"] = "FeatureCollection"
    features: List[GeoJSONFeature] = Field(default_factory=list)


class BoundingBox(BaseModel):
    min_lat: float
    min_lng: float
    max_lat: float
    max_lng: float
