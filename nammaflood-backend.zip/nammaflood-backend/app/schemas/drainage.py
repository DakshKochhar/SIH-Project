from typing import Optional

from pydantic import BaseModel

from app.schemas.common import DrainLoadLevel


class DrainageSegmentStatus(BaseModel):
    segment_id: str
    from_node: str
    to_node: str
    tier: str
    capacity_cms: float
    current_load_cms: float
    loading_ratio: float
    load_level: DrainLoadLevel
    status: str


class DrainageBottleneck(BaseModel):
    segment_id: str
    latitude: float
    longitude: float
    loading_ratio: float
    estimated_excess_flow_cms: float
    tier: str
