from typing import List, Optional

from pydantic import BaseModel

from app.schemas.common import RoadRiskLevel


class RoadRiskOut(BaseModel):
    road_id: str
    road_name: Optional[str]
    risk_score: float
    risk_level: RoadRiskLevel
    predicted_depth_cm: float
    flood_probability: float
    travel_penalty_min: float
    recommended: bool


class RoutePoint(BaseModel):
    latitude: float
    longitude: float


class SafeRouteRequest(BaseModel):
    source_lat: float
    source_lng: float
    destination_lat: float
    destination_lng: float


class SafeRouteResponse(BaseModel):
    recommended_route: List[RoutePoint]
    risk_score: float
    estimated_time_min: float
    avoided_flooded_segments: int
    is_simulated: bool = True
