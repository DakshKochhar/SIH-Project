from datetime import datetime
from typing import Dict, List, Optional

from pydantic import BaseModel, Field

from app.schemas.common import RiskLevel, DataQuality


class FloodExplanation(BaseModel):
    rainfall_contribution: float
    terrain_contribution: float
    imperviousness_contribution: float
    drainage_loading_contribution: float


class FloodPredictionOut(BaseModel):
    prediction_id: str
    latitude: float
    longitude: float
    timestamp: datetime
    forecast_horizon_min: int

    flood_probability: float = Field(..., ge=0.0, le=1.0)
    risk_level: RiskLevel
    depth_cm: float
    time_to_flood_min: Optional[int] = None

    confidence: float = Field(..., ge=0.0, le=1.0)
    data_quality: DataQuality

    main_drivers: List[str]
    explanation: FloodExplanation

    engine: str
    is_estimated: bool = Field(
        default=True,
        description="Always true: depth/probability are model estimates, not observed measurements.",
    )
    is_simulated: bool

    class Config:
        from_attributes = True


class FloodPredictionRequest(BaseModel):
    latitude: float
    longitude: float
    horizon_min: int = Field(default=180, ge=15, le=180)


class FloodHotspot(BaseModel):
    latitude: float
    longitude: float
    risk_level: RiskLevel
    flood_probability: float
    depth_cm: float
    time_to_flood_min: Optional[int]
    main_drivers: List[str]
