from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field


class RainfallObservationOut(BaseModel):
    station_id: str
    timestamp: datetime
    latitude: float
    longitude: float
    rainfall_mm: float
    rainfall_intensity: Optional[float] = None
    source: str
    quality_flag: str
    is_simulated: bool

    class Config:
        from_attributes = True


class RainfallForecastOut(BaseModel):
    grid_id: str
    latitude: float
    longitude: float
    forecast_time: datetime
    generated_at: datetime
    rainfall_mm: float
    rainfall_intensity: Optional[float] = None
    source: str
    confidence: float
    is_simulated: bool

    class Config:
        from_attributes = True


class RainfallFusionOut(BaseModel):
    """Output of the rainfall fusion module for one location."""

    latitude: float
    longitude: float
    rainfall_15min_mm: float
    rainfall_30min_mm: float
    rainfall_60min_mm: float
    rainfall_3hr_mm: float
    peak_intensity_mm_hr: float
    forecast_accumulation_mm: float
    interpolation_method: str
    contributing_stations: int
    data_quality: str
    is_simulated: bool = Field(default=True)
