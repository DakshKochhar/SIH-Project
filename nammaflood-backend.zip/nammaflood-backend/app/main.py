import asyncio
import time
from collections import defaultdict, deque

from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, PlainTextResponse

from app.api.routes import api_router, v1_router
from app.core.config import settings
from app.core.logging import configure_logging, get_logger, log_event
from app.core.security import hash_password
from app.db.base import Base
from app.db.session import SessionLocal, engine
from app.models.user import User, UserRole
from app.workers.forecast_worker import forecast_worker_loop

configure_logging("DEBUG" if settings.DEBUG else "INFO")
logger = get_logger("nammaflood.main")

app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description=(
        "NammaFlood (Team FLOWCAST) -- SIH26085 street-level urban flood nowcasting backend. "
        "Bengaluru pilot. DEMO_MODE is on by default: rainfall, drainage, terrain and land-cover "
        "data are clearly-labelled simulations until real IMD/KSNDMC/BBMP/KSRSAC/NRSC feeds are "
        "connected (see app/ingestion/)."
    ),
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Minimal in-memory rate limiting (per client IP, sliding 60s window) ---
_request_log: dict = defaultdict(deque)


@app.middleware("http")
async def rate_limit_middleware(request: Request, call_next):
    client_ip = request.client.host if request.client else "unknown"
    now = time.time()
    window = _request_log[client_ip]
    while window and now - window[0] > 60:
        window.popleft()
    if len(window) >= settings.RATE_LIMIT_PER_MINUTE:
        return JSONResponse(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            content={"detail": "Rate limit exceeded. Try again shortly."},
        )
    window.append(now)
    return await call_next(request)


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    log_event(logger, "error", "unhandled exception", path=str(request.url), error=str(exc))
    return JSONResponse(status_code=500, content={"detail": "Internal server error."})


app.include_router(api_router)
app.include_router(v1_router, prefix=settings.API_V1_PREFIX)


@app.get("/metrics", tags=["health"], summary="Basic process metrics (Prometheus-ish plaintext)")
def metrics():
    from app.workers.forecast_worker import latest_cycle_result

    lines = [
        f'nammaflood_demo_mode {1 if settings.DEMO_MODE else 0}',
        f'nammaflood_update_interval_seconds {settings.UPDATE_INTERVAL_SECONDS}',
        f'nammaflood_last_cycle_predictions {latest_cycle_result.get("predictions_generated", 0)}',
        f'nammaflood_last_cycle_alerts {latest_cycle_result.get("active_alerts", 0)}',
    ]
    return PlainTextResponse("\n".join(lines))


def _seed_admin_user() -> None:
    db = SessionLocal()
    try:
        existing = db.query(User).filter(User.email == "admin@nammaflood.demo").first()
        if existing:
            return
        admin = User(
            email="admin@nammaflood.demo",
            hashed_password=hash_password("ChangeMe123!"),
            full_name="Demo Admin",
            role=UserRole.ADMIN,
        )
        operator = User(
            email="operator@nammaflood.demo",
            hashed_password=hash_password("ChangeMe123!"),
            full_name="Demo Municipal Operator",
            role=UserRole.MUNICIPAL_OPERATOR,
        )
        citizen = User(
            email="citizen@nammaflood.demo",
            hashed_password=hash_password("ChangeMe123!"),
            full_name="Demo Citizen",
            role=UserRole.CITIZEN,
        )
        db.add_all([admin, operator, citizen])
        db.commit()
        log_event(logger, "info", "seeded demo users", emails=[admin.email, operator.email, citizen.email])
    finally:
        db.close()


@app.on_event("startup")
async def on_startup():
    Base.metadata.create_all(bind=engine)
    _seed_admin_user()
    log_event(logger, "info", "NammaFlood backend startup complete", demo_mode=settings.DEMO_MODE)
    if not settings.USE_CELERY:
        asyncio.create_task(forecast_worker_loop())


@app.get("/", include_in_schema=False)
def root():
    return {
        "service": settings.APP_NAME,
        "docs": "/docs",
        "health": "/health",
    }
