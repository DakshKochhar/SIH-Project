"""
Real-time update pipeline (prototype default: lightweight asyncio scheduler,
per `settings.USE_CELERY=False`; set True and wire a Celery beat schedule
calling `run_update_cycle()` for a production deployment instead).

Each cycle:
    1. Fetch rainfall (current + forecast)
    2. Validate rainfall (quality flags already applied by the provider)
    3. Update forecast cache
    4. Calculate catchment runoff (recomputed on-demand by services; here we
       just warm the pipeline for the dashboard locations)
    5. Calculate drainage loading
    6. Generate flood predictions
    7. Update road risk
    8. Store results (in-memory + logged; swap in DB writes for production)

Interval is `settings.UPDATE_INTERVAL_SECONDS` — no restart required to pick
up new rainfall observations, since providers are called fresh each cycle.
"""
import asyncio
from datetime import datetime, timezone

from app.core.config import settings
from app.core.logging import get_logger, log_event
from app.demo.seed_data import BENGALURU_LOCATIONS
from app.services.alert_service import get_active_alerts
from app.services.drainage_service import get_all_segment_statuses
from app.services.flood_prediction_service import predict_area
from app.services.road_risk_service import get_all_road_risks

logger = get_logger("nammaflood.worker")

# Simple in-memory cache the dashboard/API layer could read from; a
# production deployment would persist each of these into their respective
# tables (flood_predictions, road_risk, etc.) inside this same cycle.
latest_cycle_result: dict = {}


async def run_update_cycle() -> dict:
    started = datetime.now(timezone.utc)
    try:
        predictions = predict_area(
            [{"lat": loc["lat"], "lng": loc["lng"]} for loc in BENGALURU_LOCATIONS]
        )
        drainage_statuses = get_all_segment_statuses()
        road_risks = get_all_road_risks()
        alerts = get_active_alerts()

        result = {
            "cycle_started_at": started.isoformat(),
            "predictions_generated": len(predictions),
            "drainage_segments_evaluated": len(drainage_statuses),
            "road_segments_evaluated": len(road_risks),
            "active_alerts": len(alerts),
        }
        latest_cycle_result.update(result)
        log_event(logger, "info", "update cycle completed", **result)
        return result
    except Exception as exc:  # noqa: BLE001 - worker must never crash the loop
        log_event(logger, "error", "update cycle failed", error=str(exc))
        return {"error": str(exc)}


async def forecast_worker_loop() -> None:
    log_event(
        logger,
        "info",
        "forecast worker started",
        interval_seconds=settings.UPDATE_INTERVAL_SECONDS,
    )
    while True:
        await run_update_cycle()
        await asyncio.sleep(settings.UPDATE_INTERVAL_SECONDS)
