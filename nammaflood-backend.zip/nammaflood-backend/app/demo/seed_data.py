"""
Deterministic DEMO dataset for the Bengaluru pilot.

Every value produced here is SIMULATED. Locations are real, well-known
Bengaluru flood-prone areas (used only as realistic coordinates), but the
rainfall, drainage capacity, terrain and land-cover VALUES are synthetic,
generated from `settings.DEMO_RANDOM_SEED` so every demo run/reset produces
identical numbers. Nothing here should be presented as IMD/BBMP/NRSC/ESA
observed data.
"""
import random
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List

from app.core.config import settings

# Well-known Bengaluru flood-prone / low-lying locations (public knowledge,
# used only to anchor the demo grid geographically).
BENGALURU_LOCATIONS: List[Dict[str, Any]] = [
    {"name": "Silk Board Junction", "lat": 12.9172, "lng": 77.6228, "low_lying": True},
    {"name": "Bellandur", "lat": 12.9257, "lng": 77.6774, "low_lying": True},
    {"name": "Koramangala", "lat": 12.9352, "lng": 77.6245, "low_lying": False},
    {"name": "HSR Layout", "lat": 12.9116, "lng": 77.6389, "low_lying": False},
    {"name": "Hebbal", "lat": 13.0358, "lng": 77.5970, "low_lying": True},
    {"name": "Yelahanka", "lat": 13.1007, "lng": 77.5963, "low_lying": False},
    {"name": "KR Puram", "lat": 12.9944, "lng": 77.6970, "low_lying": True},
    {"name": "Marathahalli", "lat": 12.9591, "lng": 77.6974, "low_lying": True},
    {"name": "Electronic City Underpass", "lat": 12.8452, "lng": 77.6602, "low_lying": True},
    {"name": "Rajajinagar", "lat": 12.9915, "lng": 77.5540, "low_lying": False},
    {"name": "Yeshwanthpur", "lat": 13.0284, "lng": 77.5540, "low_lying": False},
    {"name": "Mahadevapura", "lat": 12.9906, "lng": 77.6970, "low_lying": True},
]


def _rng() -> random.Random:
    return random.Random(settings.DEMO_RANDOM_SEED)


def generate_rainfall_stations() -> List[Dict[str, Any]]:
    """47 ARG + 27 AWS-style stations, jittered around known locations (DEMO)."""
    rng = _rng()
    stations = []
    total = 47 + 27
    for i in range(total):
        base = BENGALURU_LOCATIONS[i % len(BENGALURU_LOCATIONS)]
        lat = base["lat"] + rng.uniform(-0.01, 0.01)
        lng = base["lng"] + rng.uniform(-0.01, 0.01)
        station_type = "ARG" if i < 47 else "AWS"
        stations.append(
            {
                "station_id": f"DEMO-{station_type}-{i+1:03d}",
                "latitude": round(lat, 5),
                "longitude": round(lng, 5),
                "type": station_type,
            }
        )
    return stations


def generate_current_rainfall(stations: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    rng = _rng()
    now = datetime.now(timezone.utc)
    observations = []
    # Simulate a moderate-to-heavy convective cell moving across the pilot area.
    storm_center = (12.95, 77.64)
    for st in stations:
        dist = ((st["latitude"] - storm_center[0]) ** 2 + (st["longitude"] - storm_center[1]) ** 2) ** 0.5
        # Closer to storm center => higher rainfall, with noise.
        base_mm = max(0.0, 45 * (1 - dist * 6)) + rng.uniform(-2, 2)
        base_mm = max(0.0, round(base_mm, 1))
        intensity = round(base_mm * rng.uniform(2.0, 4.0), 1)
        quality = "OK"
        if rng.random() < 0.05:
            quality = "MISSING"
        elif rng.random() < 0.03:
            quality = "OUTLIER"
            base_mm *= 5
        observations.append(
            {
                "station_id": st["station_id"],
                "timestamp": now,
                "latitude": st["latitude"],
                "longitude": st["longitude"],
                "rainfall_mm": base_mm,
                "rainfall_intensity": intensity,
                "source": "DEMO-IMD-KSNDMC-SIM",
                "quality_flag": quality,
                "is_simulated": True,
            }
        )
    return observations


def generate_rainfall_forecast(horizon_hours: int = 3) -> List[Dict[str, Any]]:
    rng = _rng()
    now = datetime.now(timezone.utc)
    forecasts = []
    steps = horizon_hours * 4  # 15-min steps
    for loc in BENGALURU_LOCATIONS:
        for step in range(1, steps + 1):
            forecast_time = now + timedelta(minutes=15 * step)
            decay = max(0.1, 1 - step / (steps * 1.3))
            rainfall_mm = round(max(0.0, rng.uniform(0.5, 8.0) * decay), 2)
            forecasts.append(
                {
                    "grid_id": f"GRID-{loc['name'].replace(' ', '_').upper()}",
                    "latitude": loc["lat"],
                    "longitude": loc["lng"],
                    "forecast_time": forecast_time,
                    "generated_at": now,
                    "rainfall_mm": rainfall_mm,
                    "rainfall_intensity": round(rainfall_mm * 4, 2),
                    "source": "DEMO-NOWCAST-SIM",
                    "confidence": round(max(0.35, 0.9 - step * 0.02), 2),
                    "is_simulated": True,
                }
            )
    return forecasts


def generate_drainage_network() -> Dict[str, List[Dict[str, Any]]]:
    rng = _rng()
    nodes = []
    segments = []
    for i, loc in enumerate(BENGALURU_LOCATIONS):
        node_id = f"NODE-{i+1:03d}"
        elevation = rng.uniform(870, 920) if not loc["low_lying"] else rng.uniform(860, 880)
        nodes.append(
            {
                "node_id": node_id,
                "latitude": loc["lat"],
                "longitude": loc["lng"],
                "elevation": round(elevation, 1),
                "type": "junction",
                "capacity": round(rng.uniform(5, 25), 2),
                "status": "ACTIVE",
            }
        )
    # Chain segments between consecutive nodes as a simple network (primary trunk),
    # plus a few secondary/tertiary branches.
    for i in range(len(nodes) - 1):
        tier = "primary" if i % 3 == 0 else ("secondary" if i % 3 == 1 else "tertiary")
        capacity = {"primary": rng.uniform(18, 30), "secondary": rng.uniform(8, 18), "tertiary": rng.uniform(2, 8)}[tier]
        segments.append(
            {
                "segment_id": f"SEG-{i+1:03d}",
                "from_node": nodes[i]["node_id"],
                "to_node": nodes[i + 1]["node_id"],
                "tier": tier,
                "length_m": round(rng.uniform(300, 1800), 1),
                "diameter_or_width_m": round(rng.uniform(0.6, 2.5), 2),
                "capacity_cms": round(capacity, 2),
                "current_load_cms": None,
                "slope": round(rng.uniform(0.001, 0.02), 4),
                "status": "ACTIVE",
            }
        )
    return {"nodes": nodes, "segments": segments}


def generate_terrain_grid() -> List[Dict[str, Any]]:
    rng = _rng()
    cells = []
    for i, loc in enumerate(BENGALURU_LOCATIONS):
        for j in range(5):  # small 5-cell neighbourhood per location
            lat = loc["lat"] + rng.uniform(-0.004, 0.004)
            lng = loc["lng"] + rng.uniform(-0.004, 0.004)
            elevation = rng.uniform(860, 880) if loc["low_lying"] else rng.uniform(890, 930)
            cells.append(
                {
                    "cell_id": f"TERR-{i+1:03d}-{j+1}",
                    "latitude": round(lat, 5),
                    "longitude": round(lng, 5),
                    "elevation_m": round(elevation, 1),
                    "slope_deg": round(rng.uniform(0.2, 6.0), 2),
                    "aspect_deg": round(rng.uniform(0, 360), 1),
                    "relative_elevation_m": round(elevation - 890, 1),
                    "is_local_low_point": loc["low_lying"] and j == 0,
                    "flow_accumulation": round(rng.uniform(1, 100) * (3 if loc["low_lying"] else 1), 1),
                    "dem_source": "CartoDEM-30m-DEMO",
                }
            )
    return cells


def generate_landcover_grid() -> List[Dict[str, Any]]:
    rng = _rng()
    cells = []
    for i, loc in enumerate(BENGALURU_LOCATIONS):
        for j in range(5):
            lat = loc["lat"] + rng.uniform(-0.004, 0.004)
            lng = loc["lng"] + rng.uniform(-0.004, 0.004)
            built_up = rng.uniform(0.55, 0.9) if not loc["low_lying"] else rng.uniform(0.65, 0.95)
            impervious = min(0.98, built_up + rng.uniform(0.0, 0.08))
            cells.append(
                {
                    "cell_id": f"LC-{i+1:03d}-{j+1}",
                    "latitude": round(lat, 5),
                    "longitude": round(lng, 5),
                    "landcover_type": "built-up" if built_up > 0.6 else "mixed",
                    "built_up_fraction": round(built_up, 2),
                    "impervious_fraction": round(impervious, 2),
                    "source": "ESA-WorldCover-10m-DEMO",
                }
            )
    return cells


def generate_road_network() -> Dict[str, List[Dict[str, Any]]]:
    """Simulated road graph connecting the pilot locations (DEMO topology).

    A production integration should pull real OSM ways for Bengaluru (see
    app/services/routing_service.py) — this demo topology exists only so
    the routing/road-risk endpoints are fully exercisable offline.
    """
    rng = _rng()
    locs = BENGALURU_LOCATIONS
    edges = []
    # Ring + a few chords so there is always more than one path (needed to
    # demonstrate "flood-aware" rerouting around a risky segment).
    n = len(locs)
    for i in range(n):
        j = (i + 1) % n
        edges.append((i, j))
    chords = [(0, 5), (2, 8), (3, 9), (1, 6), (4, 10), (7, 11)]
    edges.extend(chords)

    roads = []
    for idx, (i, j) in enumerate(edges):
        a, b = locs[i], locs[j]
        dist_km = ((a["lat"] - b["lat"]) ** 2 + (a["lng"] - b["lng"]) ** 2) ** 0.5 * 111
        base_speed_kmh = rng.uniform(20, 45)
        roads.append(
            {
                "road_id": f"ROAD-{idx+1:03d}",
                "road_name": f"{a['name']} - {b['name']} Rd",
                "from_lat": a["lat"],
                "from_lng": a["lng"],
                "to_lat": b["lat"],
                "to_lng": b["lng"],
                "length_km": round(max(0.3, dist_km), 2),
                "base_travel_time_min": round(max(1.0, dist_km / base_speed_kmh * 60), 1),
                "low_lying": a["low_lying"] or b["low_lying"],
            }
        )
    return {"roads": roads}


def generate_catchments(drainage_nodes: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Derive one micro-catchment per drainage node (DEMO delineation).

    A real pipeline would delineate catchments from the DEM (flow direction/
    accumulation) rather than assigning a synthetic area per node; this is a
    simplification appropriate for a prototype covering a handful of pilot
    locations.
    """
    rng = _rng()
    catchments = []
    for i, node in enumerate(drainage_nodes):
        loc = BENGALURU_LOCATIONS[i % len(BENGALURU_LOCATIONS)]
        area = rng.uniform(150_000, 900_000)  # sqm, ~0.15-0.9 sq km
        impervious = rng.uniform(0.6, 0.95) if loc["low_lying"] else rng.uniform(0.4, 0.75)
        catchments.append(
            {
                "catchment_id": f"CATCH-{i+1:03d}",
                "centroid_lat": node["latitude"],
                "centroid_lng": node["longitude"],
                "area_sqm": round(area, 1),
                "mean_elevation_m": node["elevation"],
                "mean_slope_deg": round(rng.uniform(0.5, 5.0), 2),
                "impervious_fraction": round(impervious, 3),
                "drainage_node_id": node["node_id"],
            }
        )
    return catchments


def generate_historical_flood_events() -> List[Dict[str, Any]]:
    """Small synthetic historical-event table shaped like real training data.

    NOTE: this is illustrative only — far below MODEL_MIN_TRAINING_ROWS, by
    design, so the system honestly falls back to the hybrid rules engine
    instead of pretending a real model was trained on real events.
    """
    rng = _rng()
    events = []
    now = datetime.now(timezone.utc)
    for i, loc in enumerate(BENGALURU_LOCATIONS):
        for k in range(3):
            rainfall = rng.uniform(20, 90)
            impervious = rng.uniform(0.5, 0.95)
            slope = rng.uniform(0.2, 6.0)
            elevation = rng.uniform(860, 930)
            runoff = rainfall * (0.3 + 0.6 * impervious)
            drain_loading = min(1.6, runoff / rng.uniform(15, 30))
            flooded = int(drain_loading > 0.9 and elevation < 890)
            events.append(
                {
                    "timestamp": now - timedelta(days=rng.randint(30, 900)),
                    "latitude": loc["lat"] + rng.uniform(-0.003, 0.003),
                    "longitude": loc["lng"] + rng.uniform(-0.003, 0.003),
                    "rainfall_mm": round(rainfall, 1),
                    "rainfall_intensity": round(rainfall * rng.uniform(2, 4), 1),
                    "elevation_m": round(elevation, 1),
                    "slope_deg": round(slope, 2),
                    "impervious_fraction": round(impervious, 2),
                    "runoff": round(runoff, 2),
                    "drain_loading_ratio": round(drain_loading, 2),
                    "historical_flood": flooded,
                    "observed_depth_cm": round(max(0, (drain_loading - 0.8) * 40 + rng.uniform(-3, 3)), 1)
                    if flooded
                    else 0.0,
                }
            )
    return events
