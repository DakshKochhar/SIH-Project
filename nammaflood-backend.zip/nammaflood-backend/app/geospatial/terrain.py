"""
Terrain analysis helpers.

These operate on plain dicts/lists (as returned by the ingestion providers)
rather than requiring GeoPandas/Rasterio objects, so the demo pipeline has
no hard runtime dependency on a real DEM file. A production integration
that loads an actual CartoDEM GeoTIFF via `rasterio` should compute the same
fields (elevation, slope, aspect, relative_elevation, flow_accumulation)
and feed them through this same interface.

Accuracy note: DEM posting for the pilot is ~30m (CartoDEM) / ~10m
(WorldCover). Do not report or imply centimeter-level terrain precision —
see app/services/flood_prediction_service.py for how this caveat propagates
into `confidence` and `data_quality`.
"""
import math
from typing import Dict, List, Optional


def haversine_km(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lng2 - lng1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlambda / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def nearest_terrain_cell(lat: float, lng: float, cells: List[Dict]) -> Optional[Dict]:
    if not cells:
        return None
    return min(cells, key=lambda c: haversine_km(lat, lng, c["latitude"], c["longitude"]))


def local_relative_elevation(target: Dict, neighbours: List[Dict]) -> float:
    """Elevation of `target` relative to the mean of nearby cells.

    Negative values indicate a local low point (water is more likely to
    pool there than in surrounding terrain) — this is a relative indicator,
    not an absolute flood-depth prediction.
    """
    if not neighbours:
        return 0.0
    mean_elev = sum(c["elevation_m"] for c in neighbours) / len(neighbours)
    return round(target["elevation_m"] - mean_elev, 2)


def terrain_risk_score(cell: Dict) -> float:
    """0-1 relative terrain contribution to flood risk.

    Lower (more negative) relative elevation, gentler slope (water lingers
    rather than draining away), and higher flow accumulation all raise the
    score. Coefficients are heuristic weights for the prototype, not a
    calibrated hydrological model.
    """
    rel_elev = cell.get("relative_elevation_m", 0.0)
    slope = cell.get("slope_deg", 2.0)
    flow_acc = cell.get("flow_accumulation", 10.0)

    low_point_component = max(0.0, min(1.0, -rel_elev / 15.0))  # up to -15m => 1.0
    slope_component = max(0.0, min(1.0, (5.0 - slope) / 5.0))  # flatter => higher risk
    flow_component = max(0.0, min(1.0, flow_acc / 150.0))

    score = 0.5 * low_point_component + 0.25 * slope_component + 0.25 * flow_component
    return round(min(1.0, score), 3)
