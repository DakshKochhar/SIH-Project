from typing import Dict, List, Optional

import networkx as nx

from app.geospatial.terrain import haversine_km


def build_drainage_graph(nodes: List[Dict], segments: List[Dict]) -> nx.DiGraph:
    """Build a directed graph of the stormwater drain network.

    Edge weight is travel-relevant length; `loading_ratio` and `capacity_cms`
    are stored as edge attributes so downstream services (bottleneck
    detection, flood prediction) can read them without recomputation.
    """
    g = nx.DiGraph()
    for n in nodes:
        g.add_node(n["node_id"], **n)
    for s in segments:
        g.add_edge(
            s["from_node"],
            s["to_node"],
            segment_id=s["segment_id"],
            tier=s["tier"],
            length_m=s["length_m"],
            capacity_cms=s["capacity_cms"],
            current_load_cms=s.get("current_load_cms") or 0.0,
            status=s["status"],
        )
    return g


def nearest_node(lat: float, lng: float, nodes: List[Dict]) -> Optional[Dict]:
    if not nodes:
        return None
    return min(nodes, key=lambda n: haversine_km(lat, lng, n["latitude"], n["longitude"]))


def nearest_segment(lat: float, lng: float, nodes_by_id: Dict[str, Dict], segments: List[Dict]) -> Optional[Dict]:
    """Approximate nearest segment as the one whose midpoint (from/to node
    average) is closest to the query point. Adequate for the prototype's
    chain-topology demo network; a production system with real segment
    geometry should do a proper point-to-line distance instead.
    """
    if not segments:
        return None

    def midpoint_distance(seg: Dict) -> float:
        a = nodes_by_id.get(seg["from_node"])
        b = nodes_by_id.get(seg["to_node"])
        if not a or not b:
            return float("inf")
        mid_lat = (a["latitude"] + b["latitude"]) / 2
        mid_lng = (a["longitude"] + b["longitude"]) / 2
        return haversine_km(lat, lng, mid_lat, mid_lng)

    return min(segments, key=midpoint_distance)
