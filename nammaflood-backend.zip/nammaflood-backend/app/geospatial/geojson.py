"""GeoJSON construction helpers. Coordinate order is always [lng, lat]."""
from typing import Any, Dict, List

from app.schemas.common import (
    GeoJSONFeature,
    GeoJSONFeatureCollection,
    GeoJSONPointGeometry,
    GeoJSONLineStringGeometry,
)


def point_feature(lat: float, lng: float, properties: Dict[str, Any]) -> GeoJSONFeature:
    return GeoJSONFeature(
        geometry=GeoJSONPointGeometry(coordinates=[lng, lat]),
        properties=properties,
    )


def linestring_feature(points: List[Dict[str, float]], properties: Dict[str, Any]) -> GeoJSONFeature:
    coords = [[p["longitude"], p["latitude"]] for p in points]
    return GeoJSONFeature(
        geometry=GeoJSONLineStringGeometry(coordinates=coords),
        properties=properties,
    )


def feature_collection(features: List[GeoJSONFeature]) -> GeoJSONFeatureCollection:
    return GeoJSONFeatureCollection(features=features)


def in_bbox(lat: float, lng: float, min_lat: float, min_lng: float, max_lat: float, max_lng: float) -> bool:
    return min_lat <= lat <= max_lat and min_lng <= lng <= max_lng
