from typing import Dict, List, Optional

from app.geospatial.terrain import haversine_km


def nearest_catchment(lat: float, lng: float, catchments: List[Dict]) -> Optional[Dict]:
    if not catchments:
        return None
    return min(
        catchments,
        key=lambda c: haversine_km(lat, lng, c["centroid_lat"], c["centroid_lng"]),
    )


def nearest_landcover_cell(lat: float, lng: float, cells: List[Dict]) -> Optional[Dict]:
    if not cells:
        return None
    return min(cells, key=lambda c: haversine_km(lat, lng, c["latitude"], c["longitude"]))


def local_impervious_fraction(lat: float, lng: float, landcover_cells: List[Dict], k: int = 5) -> float:
    """Average impervious fraction of the k nearest land-cover cells."""
    if not landcover_cells:
        return 0.6  # conservative default for an urban pilot area
    ranked = sorted(landcover_cells, key=lambda c: haversine_km(lat, lng, c["latitude"], c["longitude"]))
    nearest = ranked[: min(k, len(ranked))]
    return round(sum(c["impervious_fraction"] for c in nearest) / len(nearest), 3)
