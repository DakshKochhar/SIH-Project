from typing import Any, Dict, List

from app.core.config import settings
from app.demo import seed_data
from app.ingestion.base import RainfallProvider


class DemoRainfallProvider(RainfallProvider):
    """Simulated IMD/KSNDMC-style station + nowcast provider.

    All returned records are clearly marked `is_simulated=True` and carry a
    `-DEMO`/`-SIM` suffixed source string. This is NEVER real IMD/KSNDMC
    data — see app/ingestion/base.py for the no-fabrication policy.
    """

    def __init__(self) -> None:
        self._stations = seed_data.generate_rainfall_stations()

    def get_current_observations(self) -> List[Dict[str, Any]]:
        return seed_data.generate_current_rainfall(self._stations)

    def get_forecast(self, horizon_hours: int) -> List[Dict[str, Any]]:
        return seed_data.generate_rainfall_forecast(horizon_hours)


class IMDKSNDMCRainfallProvider(RainfallProvider):
    """Placeholder for a real IMD / KSNDMC integration.

    Not implemented in this prototype: doing so requires signed API
    agreements with IMD/KSNDMC. Wire real HTTP calls here using
    `settings.IMD_API_KEY` / `settings.KSNDMC_API_KEY`, keeping the same
    return shape as DemoRainfallProvider so no downstream code changes.
    """

    def get_current_observations(self) -> List[Dict[str, Any]]:
        raise NotImplementedError(
            "Real IMD/KSNDMC rainfall integration is not implemented in this prototype. "
            "Set RAINFALL_PROVIDER=demo, or implement this class against the live API."
        )

    def get_forecast(self, horizon_hours: int) -> List[Dict[str, Any]]:
        raise NotImplementedError(
            "Real IMD/KSNDMC forecast integration is not implemented in this prototype."
        )


def get_rainfall_provider() -> RainfallProvider:
    if settings.RAINFALL_PROVIDER == "demo":
        return DemoRainfallProvider()
    return IMDKSNDMCRainfallProvider()
