from typing import Any, Dict, List

from app.demo import seed_data
from app.ingestion.base import HistoricalFloodProvider


class DemoHistoricalFloodProvider(HistoricalFloodProvider):
    """Small synthetic historical-event table (see seed_data docstring).

    Deliberately sized below `settings.MODEL_MIN_TRAINING_ROWS` so the
    training pipeline honestly reports "insufficient data" rather than
    training a model on fabricated events and calling it real AI.
    """

    def get_events(self) -> List[Dict[str, Any]]:
        return seed_data.generate_historical_flood_events()


def get_historical_flood_provider() -> HistoricalFloodProvider:
    # No real provider exists for this yet (would come from BBMP disaster-
    # management records / citizen reports). Always demo for now.
    return DemoHistoricalFloodProvider()
