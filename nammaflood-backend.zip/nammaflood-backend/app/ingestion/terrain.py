from typing import Any, Dict, List

from app.core.config import settings
from app.demo import seed_data
from app.ingestion.base import TerrainProvider


class DemoTerrainProvider(TerrainProvider):
    """Simulated CartoDEM-style terrain grid (30m posting)."""

    def get_terrain_cells(self) -> List[Dict[str, Any]]:
        return seed_data.generate_terrain_grid()


class BhuvanCartoDEMProvider(TerrainProvider):
    """Placeholder for the real NRSC/Bhuvan CartoDEM integration."""

    def get_terrain_cells(self) -> List[Dict[str, Any]]:
        raise NotImplementedError(
            "Real NRSC/Bhuvan CartoDEM integration is not implemented in this prototype. "
            "A real integration should load a GeoTIFF via rasterio and derive slope/aspect "
            "with app/geospatial/terrain.py, rather than fabricating point values."
        )


def get_terrain_provider() -> TerrainProvider:
    if settings.TERRAIN_PROVIDER == "demo":
        return DemoTerrainProvider()
    return BhuvanCartoDEMProvider()
