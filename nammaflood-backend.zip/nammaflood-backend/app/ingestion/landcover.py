from typing import Any, Dict, List

from app.core.config import settings
from app.demo import seed_data
from app.ingestion.base import LandcoverProvider


class DemoLandcoverProvider(LandcoverProvider):
    """Simulated ESA WorldCover-style land cover grid (10m, built-up fraction)."""

    def get_landcover_cells(self) -> List[Dict[str, Any]]:
        return seed_data.generate_landcover_grid()


class ESAWorldCoverProvider(LandcoverProvider):
    """Placeholder for the real ESA WorldCover integration."""

    def get_landcover_cells(self) -> List[Dict[str, Any]]:
        raise NotImplementedError(
            "Real ESA WorldCover integration is not implemented in this prototype. "
            "A real integration should read the WorldCover raster tiles via rasterio."
        )


def get_landcover_provider() -> LandcoverProvider:
    if settings.LANDCOVER_PROVIDER == "demo":
        return DemoLandcoverProvider()
    return ESAWorldCoverProvider()
