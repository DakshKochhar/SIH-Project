"""
Provider interfaces for every external data source the SIH26085 proposal
identifies (IMD/KSNDMC rainfall, BBMP/KSRSAC drainage, NRSC/Bhuvan CartoDEM
terrain, ESA WorldCover land cover).

IMPORTANT — no fabricated official data:
Each interface has exactly one job: return data shaped like the real source
would. The concrete "demo" implementations (app/ingestion/*.py) generate
clearly-labelled simulated data (`is_simulated=True`, `source` strings
suffixed "-DEMO") using a deterministic seed so demos are reproducible.
Nothing here or in the demo providers is presented as, or silently
substituted for, an authoritative IMD/BBMP/NRSC/ESA feed.

To connect a real feed later: implement the same abstract method signatures
against the live API (using the API key fields already present in
app/core/config.py), and flip the relevant `*_PROVIDER` setting from
"demo" to the real provider name. No other code changes are required
because services depend on these interfaces, not on concrete classes.
"""
from abc import ABC, abstractmethod
from datetime import datetime
from typing import List, Dict, Any


class RainfallProvider(ABC):
    @abstractmethod
    def get_current_observations(self) -> List[Dict[str, Any]]:
        """Return current rainfall readings from stations/AWS/ARG."""

    @abstractmethod
    def get_forecast(self, horizon_hours: int) -> List[Dict[str, Any]]:
        """Return short-range rainfall forecast/nowcast grid points."""


class DrainageProvider(ABC):
    @abstractmethod
    def get_nodes(self) -> List[Dict[str, Any]]:
        ...

    @abstractmethod
    def get_segments(self) -> List[Dict[str, Any]]:
        ...


class TerrainProvider(ABC):
    @abstractmethod
    def get_terrain_cells(self) -> List[Dict[str, Any]]:
        ...


class LandcoverProvider(ABC):
    @abstractmethod
    def get_landcover_cells(self) -> List[Dict[str, Any]]:
        ...


class HistoricalFloodProvider(ABC):
    @abstractmethod
    def get_events(self) -> List[Dict[str, Any]]:
        """Return historical flood event records used for training/validation."""
