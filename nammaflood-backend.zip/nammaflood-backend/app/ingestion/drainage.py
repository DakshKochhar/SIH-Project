from typing import Any, Dict, List

from app.core.config import settings
from app.demo import seed_data
from app.ingestion.base import DrainageProvider


class DemoDrainageProvider(DrainageProvider):
    """Simulated BBMP/KSRSAC stormwater-drain network (nodes + segments)."""

    def __init__(self) -> None:
        self._network = seed_data.generate_drainage_network()

    def get_nodes(self) -> List[Dict[str, Any]]:
        return self._network["nodes"]

    def get_segments(self) -> List[Dict[str, Any]]:
        return self._network["segments"]


class BBMPKSRSACDrainageProvider(DrainageProvider):
    """Placeholder for the real BBMP/KSRSAC stormwater-drain KML feed."""

    def get_nodes(self) -> List[Dict[str, Any]]:
        raise NotImplementedError(
            "Real BBMP/KSRSAC drainage integration is not implemented in this prototype."
        )

    def get_segments(self) -> List[Dict[str, Any]]:
        raise NotImplementedError(
            "Real BBMP/KSRSAC drainage integration is not implemented in this prototype."
        )


def get_drainage_provider() -> DrainageProvider:
    if settings.DRAINAGE_PROVIDER == "demo":
        return DemoDrainageProvider()
    return BBMPKSRSACDrainageProvider()
