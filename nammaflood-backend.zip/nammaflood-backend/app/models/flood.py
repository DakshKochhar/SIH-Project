from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, JSON
from sqlalchemy.sql import func

from app.db.base import Base, GeometryColumn


class FloodPrediction(Base):
    """A single point-in-time, point-location flood nowcast output."""

    __tablename__ = "flood_predictions"

    id = Column(Integer, primary_key=True, index=True)
    prediction_uuid = Column(String, unique=True, index=True, nullable=False)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    timestamp = Column(DateTime(timezone=True), index=True, nullable=False)
    forecast_horizon_min = Column(Integer, nullable=False, default=180)

    flood_probability = Column(Float, nullable=False)
    risk_level = Column(String, nullable=False)  # LOW | MODERATE | HIGH | CRITICAL
    depth_cm = Column(Float, nullable=False)
    time_to_flood_min = Column(Integer, nullable=True)  # null => not imminent within horizon

    confidence = Column(Float, nullable=False)
    data_quality = Column(String, nullable=False, default="DEMO")  # FULL | PARTIAL | DEMO

    main_drivers = Column(JSON, nullable=True)  # list[str]
    explanation = Column(JSON, nullable=True)  # dict[str, float] contribution scores
    engine = Column(String, nullable=False, default="hybrid_rules")  # hybrid_rules | hybrid_ml

    geometry = Column(GeometryColumn("POINT"), nullable=True)
    is_simulated = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
