from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, ForeignKey
from sqlalchemy.sql import func

from app.db.base import Base, GeometryColumn


class TerrainCell(Base):
    """A DEM-derived terrain cell (CartoDEM, ~30m posting)."""

    __tablename__ = "terrain_cells"

    id = Column(Integer, primary_key=True, index=True)
    cell_id = Column(String, unique=True, index=True, nullable=False)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    elevation_m = Column(Float, nullable=False)
    slope_deg = Column(Float, nullable=True)
    aspect_deg = Column(Float, nullable=True)
    relative_elevation_m = Column(Float, nullable=True)  # vs local neighbourhood mean
    is_local_low_point = Column(Boolean, nullable=False, default=False)
    flow_accumulation = Column(Float, nullable=True)  # relative units, not calibrated m3
    geometry = Column(GeometryColumn("POINT"), nullable=True)
    dem_source = Column(String, nullable=False, default="CartoDEM-30m-DEMO")
    is_simulated = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class LandcoverCell(Base):
    """An ESA WorldCover-derived land cover / imperviousness cell (~10m)."""

    __tablename__ = "landcover_cells"

    id = Column(Integer, primary_key=True, index=True)
    cell_id = Column(String, unique=True, index=True, nullable=False)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    landcover_type = Column(String, nullable=False)  # built-up | tree | grass | water | bare | crop
    built_up_fraction = Column(Float, nullable=False, default=0.0)
    impervious_fraction = Column(Float, nullable=False, default=0.0)
    geometry = Column(GeometryColumn("POINT"), nullable=True)
    source = Column(String, nullable=False, default="ESA-WorldCover-10m-DEMO")
    is_simulated = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Catchment(Base):
    """A micro-catchment draining to a single drainage node — the runoff unit."""

    __tablename__ = "catchments"

    id = Column(Integer, primary_key=True, index=True)
    catchment_id = Column(String, unique=True, index=True, nullable=False)
    centroid_lat = Column(Float, nullable=False)
    centroid_lng = Column(Float, nullable=False)
    area_sqm = Column(Float, nullable=False)
    mean_elevation_m = Column(Float, nullable=True)
    mean_slope_deg = Column(Float, nullable=True)
    impervious_fraction = Column(Float, nullable=False, default=0.5)
    drainage_node_id = Column(String, ForeignKey("drainage_nodes.node_id"), nullable=True)
    geometry = Column(GeometryColumn("POLYGON"), nullable=True)
    is_simulated = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
