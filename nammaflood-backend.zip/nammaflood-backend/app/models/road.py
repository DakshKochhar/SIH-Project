from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean
from sqlalchemy.sql import func

from app.db.base import Base, GeometryColumn


class RoadRisk(Base):
    """Dynamic flood-risk score for a road segment, used for routing."""

    __tablename__ = "road_risk"

    id = Column(Integer, primary_key=True, index=True)
    road_id = Column(String, index=True, nullable=False)
    road_name = Column(String, nullable=True)
    risk_score = Column(Float, nullable=False)  # 0-100
    risk_level = Column(String, nullable=False)  # SAFE | LOW | HIGH | CRITICAL
    predicted_depth_cm = Column(Float, nullable=False, default=0.0)
    flood_probability = Column(Float, nullable=False, default=0.0)
    travel_penalty_min = Column(Float, nullable=False, default=0.0)
    recommended = Column(Boolean, nullable=False, default=True)  # False => avoid in routing
    geometry = Column(GeometryColumn("LINESTRING"), nullable=True)
    timestamp = Column(DateTime(timezone=True), index=True, nullable=False)
    is_simulated = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
