from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean
from sqlalchemy.sql import func

from app.db.base import Base


class RainfallObservation(Base):
    """A single station/AWS/ARG rainfall reading (current, not forecast)."""

    __tablename__ = "rainfall_observations"

    id = Column(Integer, primary_key=True, index=True)
    station_id = Column(String, index=True, nullable=False)
    timestamp = Column(DateTime(timezone=True), index=True, nullable=False)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    rainfall_mm = Column(Float, nullable=False)
    rainfall_intensity = Column(Float, nullable=True)  # mm/hr
    source = Column(String, nullable=False, default="DEMO")
    quality_flag = Column(String, nullable=False, default="OK")  # OK | SUSPECT | MISSING | OUTLIER
    is_simulated = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class RainfallForecast(Base):
    """A short-range (0-3hr) rainfall forecast/nowcast for a grid cell."""

    __tablename__ = "rainfall_forecasts"

    id = Column(Integer, primary_key=True, index=True)
    grid_id = Column(String, index=True, nullable=False)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    forecast_time = Column(DateTime(timezone=True), index=True, nullable=False)
    generated_at = Column(DateTime(timezone=True), nullable=False)
    rainfall_mm = Column(Float, nullable=False)
    rainfall_intensity = Column(Float, nullable=True)
    source = Column(String, nullable=False, default="DEMO")
    confidence = Column(Float, nullable=False, default=0.5)
    is_simulated = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
