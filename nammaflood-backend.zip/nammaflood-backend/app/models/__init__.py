"""Import all models here so Base.metadata sees them for create_all()/Alembic autogenerate."""
from app.models.rainfall import RainfallObservation, RainfallForecast  # noqa: F401
from app.models.drainage import DrainageNode, DrainageSegment  # noqa: F401
from app.models.terrain import TerrainCell, LandcoverCell, Catchment  # noqa: F401
from app.models.flood import FloodPrediction  # noqa: F401
from app.models.road import RoadRisk  # noqa: F401
from app.models.user import User, UserRole  # noqa: F401
