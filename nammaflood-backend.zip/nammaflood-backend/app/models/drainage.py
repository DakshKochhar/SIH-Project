from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean
from sqlalchemy.sql import func

from app.db.base import Base, GeometryColumn


class DrainageNode(Base):
    """A junction/outfall/inlet in the stormwater drain network (BBMP/KSRSAC)."""

    __tablename__ = "drainage_nodes"

    id = Column(Integer, primary_key=True, index=True)
    node_id = Column(String, unique=True, index=True, nullable=False)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    elevation = Column(Float, nullable=True)
    type = Column(String, nullable=False, default="junction")  # junction | outfall | inlet
    capacity = Column(Float, nullable=True)  # m3/s
    status = Column(String, nullable=False, default="ACTIVE")  # ACTIVE | BLOCKED | UNKNOWN
    geometry = Column(GeometryColumn("POINT"), nullable=True)
    is_simulated = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class DrainageSegment(Base):
    """A primary/secondary/tertiary stormwater drain segment between two nodes."""

    __tablename__ = "drainage_segments"

    id = Column(Integer, primary_key=True, index=True)
    segment_id = Column(String, unique=True, index=True, nullable=False)
    from_node = Column(String, index=True, nullable=False)
    to_node = Column(String, index=True, nullable=False)
    tier = Column(String, nullable=False, default="secondary")  # primary | secondary | tertiary
    length_m = Column(Float, nullable=False)
    diameter_or_width_m = Column(Float, nullable=True)
    capacity_cms = Column(Float, nullable=False)  # design capacity, m3/s
    current_load_cms = Column(Float, nullable=True)  # last computed inflow, m3/s
    slope = Column(Float, nullable=True)
    status = Column(String, nullable=False, default="ACTIVE")
    geometry = Column(GeometryColumn("LINESTRING"), nullable=True)
    is_simulated = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
