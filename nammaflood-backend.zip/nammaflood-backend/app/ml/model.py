"""
Hybrid physics + ML flood model.

Architecture (matches the SIH26085 proposal):

    INPUT FEATURES
         |
   +-----+------+
   |            |
Physics/Rule  ML Model (optional, trained via /api/v1/model/retrain)
   |            |
   +-----+------+
         |
   Ensemble Layer
         |
   Final Flood Risk

- The rule-based component is ALWAYS available and has no data dependency
  beyond the pipeline's own feature computation, so the API never fails
  outright for lack of a trained model.
- The ML component is used only when a trained artifact exists on disk
  (see app/ml/train.py). Until then, `engine="hybrid_rules"` is reported
  honestly instead of claiming ML involvement that didn't happen.
- When both are available, the ensemble is a simple weighted average,
  and `confidence` is raised slightly to reflect the extra signal.
"""
import os
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import joblib

from app.core.config import settings
from app.ml.features import FEATURE_NAMES, to_vector


@dataclass
class RuleBasedComponent:
    """Transparent, always-available rule/physics engine."""

    def score(self, features: Dict[str, float]) -> Dict[str, float]:
        rainfall_component = min(
            1.0,
            (features.get("rainfall_3hr", 0.0) + features.get("forecast_rainfall", 0.0))
            / settings.RAINFALL_NORMALISATION_MM,
        )
        terrain_component = min(1.0, max(0.0, features.get("terrain_risk", 0.0)))
        impervious_component = min(1.0, max(0.0, features.get("impervious_fraction", 0.0)))
        drainage_component = min(1.0, max(0.0, features.get("drain_loading_ratio", 0.0) / 1.5))

        probability = (
            settings.RULE_WEIGHT_RAINFALL * rainfall_component
            + settings.RULE_WEIGHT_TERRAIN * terrain_component
            + settings.RULE_WEIGHT_IMPERVIOUS * impervious_component
            + settings.RULE_WEIGHT_DRAINAGE * drainage_component
        )
        probability = round(min(1.0, max(0.0, probability)), 3)

        return {
            "probability": probability,
            "rainfall_contribution": round(settings.RULE_WEIGHT_RAINFALL * rainfall_component, 3),
            "terrain_contribution": round(settings.RULE_WEIGHT_TERRAIN * terrain_component, 3),
            "imperviousness_contribution": round(settings.RULE_WEIGHT_IMPERVIOUS * impervious_component, 3),
            "drainage_loading_contribution": round(settings.RULE_WEIGHT_DRAINAGE * drainage_component, 3),
        }


class HybridFloodModel:
    """Loads trained ML artifacts if present; always falls back to rules."""

    def __init__(self) -> None:
        self.rules = RuleBasedComponent()
        self.prob_model = None
        self.depth_model = None
        self.ttf_model = None
        self._try_load_artifacts()

    def _artifact_path(self, name: str) -> str:
        return os.path.join(settings.MODEL_ARTIFACT_DIR, name)

    def _try_load_artifacts(self) -> None:
        prob_path = self._artifact_path("flood_probability_model.joblib")
        depth_path = self._artifact_path("flood_depth_model.joblib")
        ttf_path = self._artifact_path("time_to_flood_model.joblib")
        if os.path.exists(prob_path):
            self.prob_model = joblib.load(prob_path)
        if os.path.exists(depth_path):
            self.depth_model = joblib.load(depth_path)
        if os.path.exists(ttf_path):
            self.ttf_model = joblib.load(ttf_path)

    @property
    def ml_available(self) -> bool:
        return self.prob_model is not None

    def predict(self, features: Dict[str, float]) -> Dict:
        rule_result = self.rules.score(features)

        if not self.ml_available:
            return {
                "probability": rule_result["probability"],
                "explanation": {
                    "rainfall_contribution": rule_result["rainfall_contribution"],
                    "terrain_contribution": rule_result["terrain_contribution"],
                    "imperviousness_contribution": rule_result["imperviousness_contribution"],
                    "drainage_loading_contribution": rule_result["drainage_loading_contribution"],
                },
                "engine": "hybrid_rules",
                "ml_confidence_bonus": 0.0,
            }

        vector = [to_vector(features)]
        ml_probability = float(self.prob_model.predict_proba(vector)[0][1])
        ensemble_probability = round(0.5 * rule_result["probability"] + 0.5 * ml_probability, 3)

        # Blend explanation: keep the transparent rule contributions but note
        # ML feature importances scale them, so the numbers stay honest about
        # being a blend rather than pure rule output.
        importances = getattr(self.prob_model, "feature_importances_", None)
        explanation = {
            "rainfall_contribution": rule_result["rainfall_contribution"],
            "terrain_contribution": rule_result["terrain_contribution"],
            "imperviousness_contribution": rule_result["imperviousness_contribution"],
            "drainage_loading_contribution": rule_result["drainage_loading_contribution"],
        }
        if importances is not None:
            explanation["ml_feature_importance"] = {
                name: round(float(imp), 3) for name, imp in zip(FEATURE_NAMES, importances)
            }

        return {
            "probability": ensemble_probability,
            "explanation": explanation,
            "engine": "hybrid_ml",
            "ml_confidence_bonus": 0.1,
        }

    def predict_depth_cm(self, features: Dict[str, float], probability: float) -> float:
        if self.depth_model is not None:
            vector = [to_vector(features)]
            return round(max(0.0, float(self.depth_model.predict(vector)[0])), 1)
        # Calibrated empirical fallback (ESTIMATED, not observed):
        # depth grows with excess drain loading and rainfall intensity once
        # probability crosses a moderate threshold.
        loading_ratio = features.get("drain_loading_ratio", 0.0)
        rainfall_3hr = features.get("rainfall_3hr", 0.0)
        if probability < 0.35:
            return 0.0
        excess_loading = max(0.0, loading_ratio - 0.8)
        depth = excess_loading * 35 + (rainfall_3hr / settings.RAINFALL_NORMALISATION_MM) * 20
        return round(max(0.0, min(120.0, depth)), 1)

    def predict_time_to_flood_min(self, features: Dict[str, float], probability: float) -> Optional[int]:
        if self.ttf_model is not None:
            vector = [to_vector(features)]
            return int(max(0, round(float(self.ttf_model.predict(vector)[0]))))
        if probability < 0.35:
            return None  # not imminent within the forecast horizon
        loading_ratio = features.get("drain_loading_ratio", 0.0)
        intensity = features.get("rainfall_intensity", 0.0)
        # Higher intensity + higher loading => shorter time-to-flood.
        base_minutes = 150
        minutes = base_minutes - (intensity * 1.2) - (loading_ratio * 60)
        return int(max(5, min(180, round(minutes))))


_model_singleton: Optional[HybridFloodModel] = None


def get_model() -> HybridFloodModel:
    global _model_singleton
    if _model_singleton is None:
        _model_singleton = HybridFloodModel()
    return _model_singleton


def reset_model_cache() -> None:
    """Call after retraining so newly saved artifacts are picked up."""
    global _model_singleton
    _model_singleton = None
