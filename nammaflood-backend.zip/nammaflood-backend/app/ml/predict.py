from typing import Dict

from app.ml.model import get_model


def predict_flood(features: Dict[str, float]) -> Dict:
    """Run the hybrid model end-to-end for one feature vector.

    Returns probability, depth_cm, time_to_flood_min, explanation and which
    engine actually produced the probability (hybrid_rules vs hybrid_ml).
    """
    model = get_model()
    result = model.predict(features)
    probability = result["probability"]
    depth_cm = model.predict_depth_cm(features, probability)
    ttf_min = model.predict_time_to_flood_min(features, probability)

    return {
        "probability": probability,
        "depth_cm": depth_cm,
        "time_to_flood_min": ttf_min,
        "explanation": result["explanation"],
        "engine": result["engine"],
        "ml_confidence_bonus": result["ml_confidence_bonus"],
    }
