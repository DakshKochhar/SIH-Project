"""
Feature vector definition shared by the rule-based engine, the trainable
ML model, and the explainability layer. Keeping one canonical feature list
means `main_drivers` / `explanation` always refer to the same fields the
model (or rules) actually used.
"""
from typing import Dict, List

FEATURE_NAMES: List[str] = [
    "rainfall_15min",
    "rainfall_30min",
    "rainfall_60min",
    "rainfall_3hr",
    "forecast_rainfall",
    "rainfall_intensity",
    "elevation",
    "slope",
    "impervious_fraction",
    "catchment_area",
    "runoff",
    "drain_capacity",
    "drain_loading_ratio",
    "distance_to_drain_km",
    "local_low_point",
    "historical_flood_frequency",
]


def to_vector(features: Dict[str, float]) -> List[float]:
    """Order a feature dict into the canonical vector, defaulting missing
    fields to 0.0 (their absence is reflected separately in data_quality)."""
    return [float(features.get(name, 0.0)) for name in FEATURE_NAMES]
