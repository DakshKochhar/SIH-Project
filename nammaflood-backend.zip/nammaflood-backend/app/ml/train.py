"""
Training pipeline for the ML component of the hybrid engine.

Trains three models from historical flood-event records:
  - flood probability  -> binary classification (RandomForestClassifier)
  - flood depth (cm)   -> regression (RandomForestRegressor)
  - time-to-flood (min)-> regression (RandomForestRegressor, flooded events only)

If fewer than `settings.MODEL_MIN_TRAINING_ROWS` labelled rows are
available, training is refused and the caller is told to keep using the
hybrid rules-only engine. This prototype's own demo historical dataset is
deliberately small (~36 rows) so this path is exercised honestly instead of
training on fabricated data to "prove" an ML model exists.
"""
import os
from typing import Any, Dict, List

import joblib
import numpy as np
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, mean_absolute_error

from app.core.config import settings
from app.ml.features import FEATURE_NAMES


def _row_to_features(row: Dict[str, Any]) -> List[float]:
    mapped = {
        "rainfall_15min": row.get("rainfall_mm", 0.0) * 0.25,
        "rainfall_30min": row.get("rainfall_mm", 0.0) * 0.5,
        "rainfall_60min": row.get("rainfall_mm", 0.0),
        "rainfall_3hr": row.get("rainfall_mm", 0.0) * 1.6,
        "forecast_rainfall": row.get("rainfall_mm", 0.0) * 0.3,
        "rainfall_intensity": row.get("rainfall_intensity", 0.0),
        "elevation": row.get("elevation_m", 0.0),
        "slope": row.get("slope_deg", 0.0),
        "impervious_fraction": row.get("impervious_fraction", 0.0),
        "catchment_area": row.get("catchment_area", 500_000.0),
        "runoff": row.get("runoff", 0.0),
        "drain_capacity": row.get("drain_capacity", 15.0),
        "drain_loading_ratio": row.get("drain_loading_ratio", 0.0),
        "distance_to_drain_km": row.get("distance_to_drain_km", 0.2),
        "local_low_point": 1.0 if row.get("elevation_m", 900) < 885 else 0.0,
        "historical_flood_frequency": row.get("historical_flood_frequency", 0.1),
    }
    return [mapped[name] for name in FEATURE_NAMES]


def train_models(historical_events: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Train and persist the three models. Returns a training report dict.

    Raises ValueError if there isn't enough data — callers (the
    /api/v1/model/retrain endpoint) should surface this as a 422, not
    silently fall back while claiming success.
    """
    n = len(historical_events)
    if n < settings.MODEL_MIN_TRAINING_ROWS:
        raise ValueError(
            f"Only {n} historical event rows available; "
            f"{settings.MODEL_MIN_TRAINING_ROWS} required to train. "
            "Continuing to use the hybrid rules-only engine. "
            "Connect a real historical-flood-event feed and retry."
        )

    X = np.array([_row_to_features(r) for r in historical_events])
    y_flood = np.array([r["historical_flood"] for r in historical_events])
    y_depth = np.array([r.get("observed_depth_cm", 0.0) for r in historical_events])

    flooded_idx = y_flood == 1
    X_train, X_test, y_train, y_test = train_test_split(X, y_flood, test_size=0.2, random_state=settings.DEMO_RANDOM_SEED)

    clf = RandomForestClassifier(n_estimators=200, random_state=settings.DEMO_RANDOM_SEED, max_depth=8)
    clf.fit(X_train, y_train)
    acc = accuracy_score(y_test, clf.predict(X_test))

    depth_reg = RandomForestRegressor(n_estimators=200, random_state=settings.DEMO_RANDOM_SEED, max_depth=8)
    depth_reg.fit(X, y_depth)
    depth_mae = mean_absolute_error(y_depth, depth_reg.predict(X))

    ttf_report = None
    ttf_reg = None
    if flooded_idx.sum() >= 10:
        X_flooded = X[flooded_idx]
        # Synthetic proxy target for the prototype: real training data should
        # supply an actual observed time-to-flood per event.
        y_ttf = np.array(
            [max(5, 150 - r.get("drain_loading_ratio", 0.5) * 90) for r in np.array(historical_events)[flooded_idx]]
        )
        ttf_reg = RandomForestRegressor(n_estimators=150, random_state=settings.DEMO_RANDOM_SEED, max_depth=6)
        ttf_reg.fit(X_flooded, y_ttf)
        ttf_report = {"trained_on_rows": int(flooded_idx.sum())}

    os.makedirs(settings.MODEL_ARTIFACT_DIR, exist_ok=True)
    joblib.dump(clf, os.path.join(settings.MODEL_ARTIFACT_DIR, "flood_probability_model.joblib"))
    joblib.dump(depth_reg, os.path.join(settings.MODEL_ARTIFACT_DIR, "flood_depth_model.joblib"))
    if ttf_reg is not None:
        joblib.dump(ttf_reg, os.path.join(settings.MODEL_ARTIFACT_DIR, "time_to_flood_model.joblib"))

    return {
        "rows_used": n,
        "flood_probability_model": {"accuracy": round(float(acc), 3)},
        "flood_depth_model": {"mae_cm": round(float(depth_mae), 2)},
        "time_to_flood_model": ttf_report or {"trained": False, "reason": "fewer than 10 flooded events"},
        "artifact_dir": settings.MODEL_ARTIFACT_DIR,
    }
