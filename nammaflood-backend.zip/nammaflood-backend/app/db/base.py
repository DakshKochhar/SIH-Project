"""
Declarative base and a database-portable geometry column type.

Production deployments use PostgreSQL + PostGIS (see docker-compose.yml),
so geometry columns are backed by GeoAlchemy2's `Geometry` type there. For
local development / unit tests where spinning up PostGIS is overkill, the
same column transparently degrades to a WKT text column on SQLite. This
keeps a single set of ORM models usable in both environments, which is the
"architecture designed so real municipal/live data can be connected later"
requirement without forcing every contributor to run Postgres just to run
the test suite.
"""
from sqlalchemy.orm import declarative_base
from sqlalchemy.types import TypeDecorator, Text

from app.core.config import settings

Base = declarative_base()

_IS_POSTGRES = settings.DATABASE_URL.startswith("postgresql")

if _IS_POSTGRES:
    from geoalchemy2 import Geometry as _PostGISGeometry

    def GeometryColumn(geometry_type: str = "GEOMETRY", srid: int = 4326):
        return _PostGISGeometry(geometry_type=geometry_type, srid=srid)

else:

    class _WKTGeometry(TypeDecorator):
        """Stores geometry as WKT text. Adequate for SQLite dev/test only."""

        impl = Text
        cache_ok = True

        def process_bind_param(self, value, dialect):
            return value

        def process_result_value(self, value, dialect):
            return value

    def GeometryColumn(geometry_type: str = "GEOMETRY", srid: int = 4326):
        return _WKTGeometry()
